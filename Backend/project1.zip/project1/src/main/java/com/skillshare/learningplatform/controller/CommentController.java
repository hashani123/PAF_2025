package com.skillshare.learningplatform.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.skillshare.learningplatform.dto.CommentDTO;
import com.skillshare.learningplatform.service.CommentService;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/comments")
public class CommentController {

    @Autowired
    private CommentService commentService;
    
    @GetMapping("/post/{postId}")
    public ResponseEntity<List<CommentDTO>> getCommentsByPost(@PathVariable Long postId) {
        return ResponseEntity.ok(commentService.getCommentsByPost(postId));
    }
    
    @PostMapping("/post/{postId}")
    public ResponseEntity<CommentDTO> createComment(@PathVariable Long postId,
                                                  @Valid @RequestBody CommentDTO commentDTO,
                                                  Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(commentService.createComment(commentDTO, postId, userId));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<CommentDTO> updateComment(@PathVariable Long id,
                                                  @Valid @RequestBody CommentDTO commentDTO,
                                                  Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.ok(commentService.updateComment(id, commentDTO, userId));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteComment(@PathVariable Long id, Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        commentService.deleteComment(id, userId);
        return ResponseEntity.noContent().build();
    }
}