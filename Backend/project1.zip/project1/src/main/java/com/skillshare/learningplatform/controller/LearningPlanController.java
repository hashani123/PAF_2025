package com.skillshare.learningplatform.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.skillshare.learningplatform.dto.LearningPlanDTO;
import com.skillshare.learningplatform.service.LearningPlanService;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/learning-plans")
public class LearningPlanController {

    @Autowired
    private LearningPlanService learningPlanService;
    
    @GetMapping
    public ResponseEntity<Page<LearningPlanDTO>> getAllLearningPlans(Pageable pageable) {
        return ResponseEntity.ok(learningPlanService.getAllLearningPlans(pageable));
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<LearningPlanDTO> getLearningPlanById(@PathVariable Long id) {
        return ResponseEntity.ok(learningPlanService.getLearningPlanById(id));
    }
    
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<LearningPlanDTO>> getLearningPlansByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(learningPlanService.getLearningPlansByUser(userId));
    }
    
    @GetMapping("/my-plans")
    public ResponseEntity<List<LearningPlanDTO>> getMyLearningPlans(Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.ok(learningPlanService.getLearningPlansByUser(userId));
    }
    
    @PostMapping
    public ResponseEntity<LearningPlanDTO> createLearningPlan(@Valid @RequestBody LearningPlanDTO learningPlanDTO,
                                                            Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(learningPlanService.createLearningPlan(learningPlanDTO, userId));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<LearningPlanDTO> updateLearningPlan(@PathVariable Long id,
                                                            @Valid @RequestBody LearningPlanDTO learningPlanDTO,
                                                            Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.ok(learningPlanService.updateLearningPlan(id, learningPlanDTO, userId));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLearningPlan(@PathVariable Long id, Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        learningPlanService.deleteLearningPlan(id, userId);
        return ResponseEntity.noContent().build();
    }
    
    @PatchMapping("/{planId}/milestones/{milestoneId}")
    public ResponseEntity<LearningPlanDTO> updateMilestoneStatus(@PathVariable Long planId,
                                                                @PathVariable Long milestoneId,
                                                                @RequestParam boolean completed,
                                                                Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.ok(learningPlanService.updateMilestoneStatus(planId, milestoneId, completed, userId));
    }
}