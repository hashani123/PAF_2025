package com.skillshare.learningplatform.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.skillshare.learningplatform.dto.NotificationDTO;
import com.skillshare.learningplatform.service.NotificationService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;
    
    @GetMapping
    public ResponseEntity<List<NotificationDTO>> getUserNotifications(Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.ok(notificationService.getUserNotifications(userId));
    }
    
    @GetMapping("/unread-count")
    public ResponseEntity<Map<String, Long>> getUnreadNotificationsCount(Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        long count = notificationService.getUnreadNotificationsCount(userId);
        return ResponseEntity.ok(Map.of("count", count));
    }
    
    @PatchMapping("/{id}/read")
    public ResponseEntity<Void> markNotificationAsRead(@PathVariable Long id, 
                                                    Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        notificationService.markNotificationAsRead(id, userId);
        return ResponseEntity.ok().build();
    }
    
    @PatchMapping("/mark-all-read")
    public ResponseEntity<Void> markAllNotificationsAsRead(Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        notificationService.markAllNotificationsAsRead(userId);
        return ResponseEntity.ok().build();
    }
}