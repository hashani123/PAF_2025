package com.skillshare.learningplatform.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.skillshare.learningplatform.dto.PostDTO;
import com.skillshare.learningplatform.model.Post;
import com.skillshare.learningplatform.service.PostService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/posts")
public class PostController {

    @Autowired
    private PostService postService;
    
    @GetMapping
    public ResponseEntity<Page<PostDTO>> getAllPosts(Pageable pageable) {
        return ResponseEntity.ok(postService.getAllPosts(pageable));
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<PostDTO> getPostById(@PathVariable Long id) {
        return ResponseEntity.ok(postService.getPostById(id));
    }
    
    @GetMapping("/user/{userId}")
    public ResponseEntity<Page<PostDTO>> getPostsByUser(@PathVariable Long userId, Pageable pageable) {
        return ResponseEntity.ok(postService.getPostsByUser(userId, pageable));
    }
    
    @GetMapping("/category/{category}")
    public ResponseEntity<Page<PostDTO>> getPostsByCategory(@PathVariable String category, Pageable pageable) {
        try {
            Post.Category categoryEnum = Post.Category.valueOf(category.toUpperCase());
            return ResponseEntity.ok(postService.getPostsByCategory(categoryEnum, pageable));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @GetMapping("/feed")
    public ResponseEntity<Page<PostDTO>> getFollowedUsersPosts(Authentication authentication, Pageable pageable) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.ok(postService.getFollowedUsersPosts(userId, pageable));
    }
    
    @PostMapping
    public ResponseEntity<PostDTO> createPost(@Valid @RequestBody PostDTO postDTO,
                                            Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(postService.createPost(postDTO, userId));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<PostDTO> updatePost(@PathVariable Long id,
                                            @Valid @RequestBody PostDTO postDTO,
                                            Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.ok(postService.updatePost(id, postDTO, userId));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePost(@PathVariable Long id, Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        postService.deletePost(id, userId);
        return ResponseEntity.noContent().build();
    }
    
    @PostMapping("/{id}/like")
    public ResponseEntity<PostDTO> likePost(@PathVariable Long id, Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.ok(postService.likePost(id, userId));
    }
    
    @DeleteMapping("/{id}/like")
    public ResponseEntity<PostDTO> unlikePost(@PathVariable Long id, Authentication authentication) {
        Long userId = Long.parseLong(authentication.getName());
        return ResponseEntity.ok(postService.unlikePost(id, userId));
    }
}