package com.skillshare.learningplatform.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.skillshare.learningplatform.dto.UserDTO;
import com.skillshare.learningplatform.service.UserService;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;
    
    @GetMapping
    public ResponseEntity<List<UserDTO>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<UserDTO> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }
    
    @GetMapping("/username/{username}")
    public ResponseEntity<UserDTO> getUserByUsername(@PathVariable String username) {
        return ResponseEntity.ok(userService.getUserByUsername(username));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<UserDTO> updateUser(@PathVariable Long id, 
                                            @Valid @RequestBody UserDTO userDTO,
                                            Authentication authentication) {
        // Extract user id from authentication
        Long authUserId = Long.parseLong(authentication.getName());
        
        // Check if the authenticated user is trying to update their own profile
        if (!id.equals(authUserId)) {
            return ResponseEntity.status(403).build();
        }
        
        return ResponseEntity.ok(userService.updateUser(id, userDTO));
    }
    
    @PostMapping("/{id}/follow")
    public ResponseEntity<Void> followUser(@PathVariable Long id, Authentication authentication) {
        // Extract follower id from authentication
        Long followerId = Long.parseLong(authentication.getName());
        
        userService.followUser(followerId, id);
        return ResponseEntity.ok().build();
    }
    
    @DeleteMapping("/{id}/follow")
    public ResponseEntity<Void> unfollowUser(@PathVariable Long id, Authentication authentication) {
        // Extract follower id from authentication
        Long followerId = Long.parseLong(authentication.getName());
        
        userService.unfollowUser(followerId, id);
        return ResponseEntity.ok().build();
    }
}