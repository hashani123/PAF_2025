package com.skillshare.learningplatform.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CommentDTO {
    private Long id;
    
    @NotBlank
    private String content;
    
    private Long userId;
    
    private String username;
    
    private Long postId;
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
}