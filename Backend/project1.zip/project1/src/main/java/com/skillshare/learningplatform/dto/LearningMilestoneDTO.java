package com.skillshare.learningplatform.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LearningMilestoneDTO {
    private Long id;
    
    @NotBlank
    private String title;
    
    private String description;
    
    private boolean completed;
    
    private LocalDateTime completedAt;
}