package com.skillshare.learningplatform.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LearningPlanDTO {
    private Long id;
    
    @NotBlank
    private String title;
    
    private String description;
    
    private LocalDateTime targetCompletionDate;
    
    private String status;
    
    private Long userId;
    
    private String username;
    
    private int progress;
    
    private List<LearningMilestoneDTO> milestones = new ArrayList<>();
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
}