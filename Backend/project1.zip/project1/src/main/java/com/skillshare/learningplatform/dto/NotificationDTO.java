package com.skillshare.learningplatform.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class NotificationDTO {
    private Long id;
    private String type;
    private String content;
    private boolean read;
    private Long actorId;
    private String actorUsername;
    private Long postId;
    private Long commentId;
    private LocalDateTime createdAt;
}