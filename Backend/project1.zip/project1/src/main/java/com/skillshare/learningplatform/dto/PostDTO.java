package com.skillshare.learningplatform.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PostDTO {
    private Long id;
    
    @NotBlank
    private String title;
    
    @NotBlank
    private String description;
    
    private String category;
    
    private Long userId;
    
    private String username;
    
    private int likesCount;
    
    private int commentsCount;
    
    private List<MediaDTO> media = new ArrayList<>();
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
    
    @Data
    public static class MediaDTO {
        private Long id;
        private String filePath;
        private String type;
    }
}