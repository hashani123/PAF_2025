package com.skillshare.learningplatform.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class UserDTO {
    private Long id;
    private String username;
    private String email;
    private String fullName;
    private String bio;
    private String profilePicture;
    private int followersCount;
    private int followingCount;
    private LocalDateTime createdAt;
}