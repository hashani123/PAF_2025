package com.skillshare.learningplatform.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "media")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Media {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String filePath;
    
    @Enumerated(EnumType.STRING)
    private MediaType type;
    
    @ManyToOne
    @JoinColumn(name = "post_id")
    private Post post;
    
    public enum MediaType {
        IMAGE,
        VIDEO
    }
}