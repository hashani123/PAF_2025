package com.skillshare.learningplatform.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.skillshare.learningplatform.model.Comment;
import com.skillshare.learningplatform.model.Post;
import com.skillshare.learningplatform.model.User;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByPost(Post post);
    
    List<Comment> findByUser(User user);
}