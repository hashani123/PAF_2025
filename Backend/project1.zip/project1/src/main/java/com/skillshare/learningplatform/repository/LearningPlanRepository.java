package com.skillshare.learningplatform.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.skillshare.learningplatform.model.LearningPlan;
import com.skillshare.learningplatform.model.User;
import com.skillshare.learningplatform.model.LearningPlan.Status;

public interface LearningPlanRepository extends JpaRepository<LearningPlan, Long> {
    List<LearningPlan> findByUser(User user);
    
    Page<LearningPlan> findByUser(User user, Pageable pageable);
    
    List<LearningPlan> findByUserAndStatus(User user, Status status);
    
    @Query("SELECT lp FROM LearningPlan lp WHERE lp.title LIKE %:keyword% OR lp.description LIKE %:keyword%")
    Page<LearningPlan> searchLearningPlans(@Param("keyword") String keyword, Pageable pageable);
}