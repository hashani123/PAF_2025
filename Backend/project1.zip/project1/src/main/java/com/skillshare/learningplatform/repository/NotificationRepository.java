package com.skillshare.learningplatform.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.skillshare.learningplatform.model.Notification;
import com.skillshare.learningplatform.model.User;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByRecipient(User recipient, Sort sort);
    
    List<Notification> findByRecipientAndRead(User recipient, boolean read, Sort sort);
    
    long countByRecipientAndRead(User recipient, boolean read);
}