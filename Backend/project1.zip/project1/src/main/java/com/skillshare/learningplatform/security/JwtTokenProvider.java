package com.skillshare.learningplatform.security;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

import java.security.Key;
import java.util.Base64;

@Component
public class JwtTokenProvider {

    @Value("${app.jwt.secret}")
    private String jwtSecret;

    @Value("${app.jwt.expiration}")
    private int jwtExpirationInMs;

    // Generate token
    public String generateToken(Authentication authentication) {
        String username = authentication.getName();
        
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + jwtExpirationInMs);
        
        byte[] keyBytes = Base64.getDecoder().decode(jwtSecret.getBytes());
        Key key = Keys.hmacShaKeyFor(keyBytes);

        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(expiryDate)
                .signWith(key, SignatureAlgorithm.HS512)
                .compact();
    }
    
    // Get username from token
    public String getUsernameFromToken(String token) {
        byte[] keyBytes = Base64.getDecoder().decode(jwtSecret.getBytes());
        Key key = Keys.hmacShaKeyFor(keyBytes);
        
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();

        return claims.getSubject();
    }
    
    // Validate token
    public boolean validateToken(String token) {
        try {
            byte[] keyBytes = Base64.getDecoder().decode(jwtSecret.getBytes());
            Key key = Keys.hmacShaKeyFor(keyBytes);
            
            Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }
}