package com.skillshare.learningplatform.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillshare.learningplatform.dto.CommentDTO;
import com.skillshare.learningplatform.exception.ResourceNotFoundException;
import com.skillshare.learningplatform.exception.UnauthorizedException;
import com.skillshare.learningplatform.model.Comment;
import com.skillshare.learningplatform.model.Post;
import com.skillshare.learningplatform.model.User;
import com.skillshare.learningplatform.repository.CommentRepository;
import com.skillshare.learningplatform.repository.PostRepository;
import com.skillshare.learningplatform.repository.UserRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;
    
    @Autowired
    private PostRepository postRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private NotificationService notificationService;
    
    public List<CommentDTO> getCommentsByPost(Long postId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found"));
        
        return commentRepository.findByPost(post).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
    
    @Transactional
    public CommentDTO createComment(CommentDTO commentDTO, Long postId, Long userId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found"));
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Comment comment = new Comment();
        comment.setContent(commentDTO.getContent());
        comment.setPost(post);
        comment.setUser(user);
        
        Comment savedComment = commentRepository.save(comment);
        
        // Create notification if the commenter is not the post owner
        if (!post.getUser().getId().equals(userId)) {
            notificationService.createCommentNotification(user, post.getUser(), post, savedComment);
        }
        
        return convertToDTO(savedComment);
    }
    
    @Transactional
    public CommentDTO updateComment(Long commentId, CommentDTO commentDTO, Long userId) {
        Comment comment = commentRepository.findById(commentId)
                .orElseThrow(() -> new ResourceNotFoundException("Comment not found"));
        
        // Check if the user is the owner of the comment
        if (!comment.getUser().getId().equals(userId)) {
            throw new UnauthorizedException("You don't have permission to update this comment");
        }
        
        comment.setContent(commentDTO.getContent());
        Comment updatedComment = commentRepository.save(comment);
        
        return convertToDTO(updatedComment);
    }
    
    @Transactional
    public void deleteComment(Long commentId, Long userId) {
        Comment comment = commentRepository.findById(commentId)
                .orElseThrow(() -> new ResourceNotFoundException("Comment not found"));
        
        // Check if the user is the owner of the comment or the post
        if (!comment.getUser().getId().equals(userId) && 
            !comment.getPost().getUser().getId().equals(userId)) {
            throw new UnauthorizedException("You don't have permission to delete this comment");
        }
        
        commentRepository.delete(comment);
    }
    
    private CommentDTO convertToDTO(Comment comment) {
        CommentDTO dto = new CommentDTO();
        dto.setId(comment.getId());
        dto.setContent(comment.getContent());
        dto.setUserId(comment.getUser().getId());
        dto.setUsername(comment.getUser().getUsername());
        dto.setPostId(comment.getPost().getId());
        dto.setCreatedAt(comment.getCreatedAt());
        dto.setUpdatedAt(comment.getUpdatedAt());
        return dto;
    }
}