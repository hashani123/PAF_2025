package com.skillshare.learningplatform.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillshare.learningplatform.dto.LearningMilestoneDTO;
import com.skillshare.learningplatform.dto.LearningPlanDTO;
import com.skillshare.learningplatform.exception.ResourceNotFoundException;
import com.skillshare.learningplatform.exception.UnauthorizedException;
import com.skillshare.learningplatform.model.LearningMilestone;
import com.skillshare.learningplatform.model.LearningPlan;
import com.skillshare.learningplatform.model.User;
import com.skillshare.learningplatform.repository.LearningPlanRepository;
import com.skillshare.learningplatform.repository.UserRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LearningPlanService {

    @Autowired
    private LearningPlanRepository learningPlanRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    public Page<LearningPlanDTO> getAllLearningPlans(Pageable pageable) {
        return learningPlanRepository.findAll(pageable)
                .map(this::convertToDTO);
    }
    
    public List<LearningPlanDTO> getLearningPlansByUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        return learningPlanRepository.findByUser(user).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
    
    public LearningPlanDTO getLearningPlanById(Long id) {
        LearningPlan learningPlan = learningPlanRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Learning plan not found"));
        
        return convertToDTO(learningPlan);
    }
    
    @Transactional
    public LearningPlanDTO createLearningPlan(LearningPlanDTO learningPlanDTO, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        LearningPlan learningPlan = new LearningPlan();
        learningPlan.setTitle(learningPlanDTO.getTitle());
        learningPlan.setDescription(learningPlanDTO.getDescription());
        learningPlan.setTargetCompletionDate(learningPlanDTO.getTargetCompletionDate());
        learningPlan.setStatus(LearningPlan.Status.valueOf(learningPlanDTO.getStatus()));
        learningPlan.setUser(user);
        
        LearningPlan savedLearningPlan = learningPlanRepository.save(learningPlan);
        
        // Create milestones if provided
        if (learningPlanDTO.getMilestones() != null && !learningPlanDTO.getMilestones().isEmpty()) {
            for (LearningMilestoneDTO milestoneDTO : learningPlanDTO.getMilestones()) {
                LearningMilestone milestone = new LearningMilestone();
                milestone.setTitle(milestoneDTO.getTitle());
                milestone.setDescription(milestoneDTO.getDescription());
                milestone.setCompleted(false);
                milestone.setLearningPlan(savedLearningPlan);
                
                savedLearningPlan.getMilestones().add(milestone);
            }
            
            // Save the learning plan with milestones
            savedLearningPlan = learningPlanRepository.save(savedLearningPlan);
        }
        
        return convertToDTO(savedLearningPlan);
    }
    
    @Transactional
    public LearningPlanDTO updateLearningPlan(Long id, LearningPlanDTO learningPlanDTO, Long userId) {
        LearningPlan learningPlan = learningPlanRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Learning plan not found"));
        
        // Check if the user is the owner of the learning plan
        if (!learningPlan.getUser().getId().equals(userId)) {
            throw new UnauthorizedException("You don't have permission to update this learning plan");
        }
        
        learningPlan.setTitle(learningPlanDTO.getTitle());
        learningPlan.setDescription(learningPlanDTO.getDescription());
        learningPlan.setTargetCompletionDate(learningPlanDTO.getTargetCompletionDate());
        learningPlan.setStatus(LearningPlan.Status.valueOf(learningPlanDTO.getStatus()));
        
        LearningPlan updatedLearningPlan = learningPlanRepository.save(learningPlan);
        return convertToDTO(updatedLearningPlan);
    }
    
    @Transactional
    public void deleteLearningPlan(Long id, Long userId) {
        LearningPlan learningPlan = learningPlanRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Learning plan not found"));
        
        // Check if the user is the owner of the learning plan
        if (!learningPlan.getUser().getId().equals(userId)) {
            throw new UnauthorizedException("You don't have permission to delete this learning plan");
        }
        
        learningPlanRepository.delete(learningPlan);
    }
    
    @Transactional
    public LearningPlanDTO updateMilestoneStatus(Long planId, Long milestoneId, boolean completed, Long userId) {
        LearningPlan learningPlan = learningPlanRepository.findById(planId)
                .orElseThrow(() -> new ResourceNotFoundException("Learning plan not found"));
        
        // Check if the user is the owner of the learning plan
        if (!learningPlan.getUser().getId().equals(userId)) {
            throw new UnauthorizedException("You don't have permission to update this learning plan");
        }
        
        // Find the milestone
        LearningMilestone milestone = learningPlan.getMilestones().stream()
                .filter(m -> m.getId().equals(milestoneId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Milestone not found"));
        
        milestone.setCompleted(completed);
        
        // Check if all milestones are completed, update plan status if needed
        boolean allCompleted = learningPlan.getMilestones().stream()
                .allMatch(LearningMilestone::isCompleted);
        
        if (allCompleted) {
            learningPlan.setStatus(LearningPlan.Status.COMPLETED);
        }
        
        LearningPlan updatedPlan = learningPlanRepository.save(learningPlan);
        return convertToDTO(updatedPlan);
    }
    
    private LearningPlanDTO convertToDTO(LearningPlan learningPlan) {
        LearningPlanDTO dto = new LearningPlanDTO();
        dto.setId(learningPlan.getId());
        dto.setTitle(learningPlan.getTitle());
        dto.setDescription(learningPlan.getDescription());
        dto.setTargetCompletionDate(learningPlan.getTargetCompletionDate());
        dto.setStatus(learningPlan.getStatus().name());
        dto.setUserId(learningPlan.getUser().getId());
        dto.setUsername(learningPlan.getUser().getUsername());
        dto.setCreatedAt(learningPlan.getCreatedAt());
        dto.setUpdatedAt(learningPlan.getUpdatedAt());
        
        // Convert milestones to DTOs
        dto.setMilestones(learningPlan.getMilestones().stream()
                .map(milestone -> {
                    LearningMilestoneDTO milestoneDTO = new LearningMilestoneDTO();
                    milestoneDTO.setId(milestone.getId());
                    milestoneDTO.setTitle(milestone.getTitle());
                    milestoneDTO.setDescription(milestone.getDescription());
                    milestoneDTO.setCompleted(milestone.isCompleted());
                    milestoneDTO.setCompletedAt(milestone.getCompletedAt());
                    return milestoneDTO;
                })
                .collect(Collectors.toList()));
        
        // Calculate progress
        if (!learningPlan.getMilestones().isEmpty()) {
            long completedCount = learningPlan.getMilestones().stream()
                    .filter(LearningMilestone::isCompleted)
                    .count();
            
            double progress = (double) completedCount / learningPlan.getMilestones().size() * 100;
            dto.setProgress((int) progress);
        } else {
            dto.setProgress(0);
        }
        
        return dto;
    }
}