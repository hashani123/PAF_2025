package com.skillshare.learningplatform.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillshare.learningplatform.dto.NotificationDTO;
import com.skillshare.learningplatform.exception.ResourceNotFoundException;
import com.skillshare.learningplatform.exception.UnauthorizedException;
import com.skillshare.learningplatform.model.Comment;
import com.skillshare.learningplatform.model.Notification;
import com.skillshare.learningplatform.model.Post;
import com.skillshare.learningplatform.model.User;
import com.skillshare.learningplatform.repository.NotificationRepository;
import com.skillshare.learningplatform.repository.UserRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    public List<NotificationDTO> getUserNotifications(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Sort sort = Sort.by(Sort.Direction.DESC, "createdAt");
        
        return notificationRepository.findByRecipient(user, sort).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
    
    public long getUnreadNotificationsCount(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        return notificationRepository.countByRecipientAndRead(user, false);
    }
    
    @Transactional
    public void markNotificationAsRead(Long notificationId, Long userId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
        
        // Check if the user is the recipient of the notification
        if (!notification.getRecipient().getId().equals(userId)) {
            throw new UnauthorizedException("You don't have permission to mark this notification as read");
        }
        
        notification.setRead(true);
        notificationRepository.save(notification);
    }
    
    @Transactional
    public void markAllNotificationsAsRead(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Sort sort = Sort.by(Sort.Direction.DESC, "createdAt");
        List<Notification> notifications = notificationRepository.findByRecipientAndRead(user, false, sort);
        
        notifications.forEach(notification -> notification.setRead(true));
        notificationRepository.saveAll(notifications);
    }
    
    @Async
    @Transactional
    public void createLikeNotification(User actor, User recipient, Post post) {
        Notification notification = new Notification();
        notification.setActor(actor);
        notification.setRecipient(recipient);
        notification.setPost(post);
        notification.setType(Notification.NotificationType.LIKE);
        notification.setContent(actor.getUsername() + " liked your post");
        
        notificationRepository.save(notification);
    }
    
    @Async
    @Transactional
    public void createCommentNotification(User actor, User recipient, Post post, Comment comment) {
        Notification notification = new Notification();
        notification.setActor(actor);
        notification.setRecipient(recipient);
        notification.setPost(post);
        notification.setComment(comment);
        notification.setType(Notification.NotificationType.COMMENT);
        notification.setContent(actor.getUsername() + " commented on your post");
        
        notificationRepository.save(notification);
    }
    
    @Async
    @Transactional
    public void createFollowNotification(User actor, User recipient) {
        Notification notification = new Notification();
        notification.setActor(actor);
        notification.setRecipient(recipient);
        notification.setType(Notification.NotificationType.FOLLOW);
        notification.setContent(actor.getUsername() + " started following you");
        
        notificationRepository.save(notification);
    }
    
    private NotificationDTO convertToDTO(Notification notification) {
        NotificationDTO dto = new NotificationDTO();
        dto.setId(notification.getId());
        dto.setType(notification.getType().name());
        dto.setContent(notification.getContent());
        dto.setRead(notification.isRead());
        dto.setActorId(notification.getActor().getId());
        dto.setActorUsername(notification.getActor().getUsername());
        dto.setCreatedAt(notification.getCreatedAt());
        
        if (notification.getPost() != null) {
            dto.setPostId(notification.getPost().getId());
        }
        
        if (notification.getComment() != null) {
            dto.setCommentId(notification.getComment().getId());
        }
        
        return dto;
    }
}