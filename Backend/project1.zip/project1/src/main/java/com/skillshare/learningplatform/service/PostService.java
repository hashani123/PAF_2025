package com.skillshare.learningplatform.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.skillshare.learningplatform.dto.PostDTO;
import com.skillshare.learningplatform.exception.ResourceNotFoundException;
import com.skillshare.learningplatform.exception.UnauthorizedException;
import com.skillshare.learningplatform.model.Media;
import com.skillshare.learningplatform.model.Post;
import com.skillshare.learningplatform.model.User;
import com.skillshare.learningplatform.repository.PostRepository;
import com.skillshare.learningplatform.repository.UserRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@SuppressWarnings("unused")
@Service
public class PostService {

    @Autowired
    private PostRepository postRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private NotificationService notificationService;
    
    public Page<PostDTO> getAllPosts(Pageable pageable) {
        return postRepository.findAll(pageable)
                .map(this::convertToDTO);
    }
    
    public Page<PostDTO> getPostsByUser(Long userId, Pageable pageable) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        return postRepository.findByUser(user, pageable)
                .map(this::convertToDTO);
    }
    
    public Page<PostDTO> getPostsByCategory(Post.Category category, Pageable pageable) {
        return postRepository.findByCategory(category, pageable)
                .map(this::convertToDTO);
    }
    
    public Page<PostDTO> getFollowedUsersPosts(Long userId, Pageable pageable) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        List<User> following = new ArrayList<>(user.getFollowing());
        
        return postRepository.findByUserIn(following, pageable)
                .map(this::convertToDTO);
    }
    
    public PostDTO getPostById(Long id) {
        Post post = postRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found"));
        
        return convertToDTO(post);
    }
    
    @Transactional
    public PostDTO createPost(PostDTO postDTO, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Post post = new Post();
        post.setTitle(postDTO.getTitle());
        post.setDescription(postDTO.getDescription());
        post.setCategory(Post.Category.valueOf(postDTO.getCategory()));
        post.setUser(user);
        
        Post savedPost = postRepository.save(post);
        
        // Handle media files separately, typically would be another service
        
        return convertToDTO(savedPost);
    }
    
    @Transactional
    public PostDTO updatePost(Long id, PostDTO postDTO, Long userId) {
        Post post = postRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found"));
        
        // Check if the user is the owner of the post
        if (!post.getUser().getId().equals(userId)) {
            throw new UnauthorizedException("You don't have permission to update this post");
        }
        
        post.setTitle(postDTO.getTitle());
        post.setDescription(postDTO.getDescription());
        post.setCategory(Post.Category.valueOf(postDTO.getCategory()));
        
        Post updatedPost = postRepository.save(post);
        return convertToDTO(updatedPost);
    }
    
    @Transactional
    public void deletePost(Long id, Long userId) {
        Post post = postRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found"));
        
        // Check if the user is the owner of the post
        if (!post.getUser().getId().equals(userId)) {
            throw new UnauthorizedException("You don't have permission to delete this post");
        }
        
        postRepository.delete(post);
    }
    
    @Transactional
    public PostDTO likePost(Long postId, Long userId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found"));
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        post.getLikes().add(user);
        Post updatedPost = postRepository.save(post);
        
        // Create notification if the user liking is not the post owner
        if (!post.getUser().getId().equals(userId)) {
            notificationService.createLikeNotification(user, post.getUser(), post);
        }
        
        return convertToDTO(updatedPost);
    }
    
    @Transactional
    public PostDTO unlikePost(Long postId, Long userId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found"));
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        post.getLikes().remove(user);
        Post updatedPost = postRepository.save(post);
        
        return convertToDTO(updatedPost);
    }
    
    private PostDTO convertToDTO(Post post) {
        PostDTO dto = new PostDTO();
        dto.setId(post.getId());
        dto.setTitle(post.getTitle());
        dto.setDescription(post.getDescription());
        dto.setCategory(post.getCategory().name());
        dto.setUserId(post.getUser().getId());
        dto.setUsername(post.getUser().getUsername());
        dto.setLikesCount(post.getLikes().size());
        dto.setCommentsCount(post.getComments().size());
        dto.setCreatedAt(post.getCreatedAt());
        dto.setUpdatedAt(post.getUpdatedAt());
        
        // Convert media to DTOs
        dto.setMedia(post.getMedia().stream()
                .map(media -> {
                    PostDTO.MediaDTO mediaDTO = new PostDTO.MediaDTO();
                    mediaDTO.setId(media.getId());
                    mediaDTO.setFilePath(media.getFilePath());
                    mediaDTO.setType(media.getType().name());
                    return mediaDTO;
                })
                .collect(Collectors.toList()));
        
        return dto;
    }
}