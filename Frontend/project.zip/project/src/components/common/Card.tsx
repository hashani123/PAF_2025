import { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  hoverable?: boolean;
}

const Card = ({
  children,
  className = '',
  padding = 'md',
  hoverable = false,
}: CardProps) => {
  const paddingClasses = {
    none: '',
    sm: 'p-3',
    md: 'p-4',
    lg: 'p-6',
  };

  const classes = [
    'bg-white rounded-lg border border-neutral-200 shadow-sm',
    paddingClasses[padding],
    hoverable ? 'transition-all duration-200 hover:shadow-md' : '',
    className,
  ].join(' ');

  return <div className={classes}>{children}</div>;
};

export default Card;