import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import MobileNavbar from './MobileNavbar';
import { useAuth } from '../../context/AuthContext';

const Layout = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="flex min-h-screen bg-neutral-50">
      {/* Sidebar - only visible on larger screens */}
      <div className="hidden md:block md:w-60 lg:w-64 h-screen fixed">
        <Sidebar />
      </div>

      {/* Main content area */}
      <div className="flex-1 md:ml-60 lg:ml-64">
        {/* Main content container */}
        <div className="max-w-5xl mx-auto px-4 pb-20 pt-4 md:pt-6">
          <Outlet />
        </div>
      </div>

      {/* Mobile navigation bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-10">
        <MobileNavbar />
      </div>
    </div>
  );
};

export default Layout;