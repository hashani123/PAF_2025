import { Link, useLocation } from 'react-router-dom';
import { Home, User, Compass, Calendar, PenSquare } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';

const MobileNavbar = () => {
  const location = useLocation();
  const { user } = useAuth();

  const navigationItems = [
    { name: 'Home', icon: Home, path: '/' },
    { name: 'Explore', icon: Compass, path: '/explore' },
    { name: 'Create', icon: PenSquare, path: '/create' },
    { name: 'Plans', icon: Calendar, path: '/learning-plans' },
    { name: 'Profile', icon: User, path: `/profile/${user?.id}` },
  ];

  return (
    <nav className="bg-white border-t border-neutral-200 px-2 py-3">
      <ul className="flex justify-around">
        {navigationItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <li key={item.name}>
              <Link
                to={item.path}
                className="flex flex-col items-center px-1 relative"
              >
                <div className={`p-1.5 ${isActive ? 'text-primary-600' : 'text-neutral-600'}`}>
                  <item.icon className="h-5 w-5" />
                  {isActive && (
                    <motion.div
                      layoutId="mobile-nav-dot"
                      className="absolute bottom-0 left-1/2 transform -translate-x-1/2 h-1 w-1 bg-primary-600 rounded-full" 
                      transition={{ type: 'spring', duration: 0.5 }}
                    />
                  )}
                </div>
                <span className={`text-xs mt-1 ${isActive ? 'text-primary-600 font-medium' : 'text-neutral-600'}`}>
                  {item.name}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
};

export default MobileNavbar;