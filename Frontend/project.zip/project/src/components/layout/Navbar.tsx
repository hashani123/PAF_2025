import { Bell, Search, User, LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const { unreadCount } = useNotifications();

  return (
    <nav className="bg-white border-b border-neutral-200 py-3 px-4 flex items-center justify-between">
      <div className="flex items-center">
        <Link to="/" className="text-xl font-bold text-primary-600">
          SkillShare
        </Link>
      </div>

      <div className="hidden md:flex items-center flex-1 max-w-md mx-6">
        <div className="relative w-full">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-neutral-400" />
          </div>
          <input
            type="text"
            className="block w-full bg-neutral-50 border border-neutral-300 rounded-lg py-2 pl-10 pr-3 text-sm placeholder-neutral-500"
            placeholder="Search for skills, users, topics..."
          />
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <Link
          to="/notifications"
          className="relative p-1 rounded-full hover:bg-neutral-100 transition-colors"
        >
          <Bell className="h-5 w-5 text-neutral-700" />
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 -mt-1 -mr-1 bg-error-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </Link>

        {user ? (
          <div className="flex items-center">
            <Link
              to={`/profile/${user.id}`}
              className="flex items-center mr-4 hover:text-primary-600 transition-colors"
            >
              <img
                src={user.avatarUrl}
                alt={user.name}
                className="h-8 w-8 rounded-full object-cover mr-2"
              />
              <span className="hidden lg:inline font-medium">{user.name}</span>
            </Link>
            <button
              onClick={logout}
              className="text-neutral-600 hover:text-error-600 p-1 rounded-full hover:bg-neutral-100 transition-colors"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        ) : (
          <button className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors">
            Sign In
          </button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;