import { Link, useLocation } from 'react-router-dom';
import { Home, User, Compass, Calendar, PenSquare, Bell, Bookmark } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';

const Sidebar = () => {
  const location = useLocation();
  const { user } = useAuth();

  const navigationItems = [
    { name: 'Home', icon: Home, path: '/' },
    { name: 'Explore', icon: Compass, path: '/explore' },
    { name: 'Learning Plans', icon: Calendar, path: '/learning-plans' },
    { name: 'Create', icon: PenSquare, path: '/create' },
    { name: 'Notifications', icon: Bell, path: '/notifications' },
    { name: 'Bookmarks', icon: Bookmark, path: '/bookmarks' },
    { name: 'Profile', icon: User, path: `/profile/${user?.id}` },
  ];

  return (
    <div className="h-full bg-white border-r border-neutral-200 py-6 flex flex-col">
      <div className="px-6 mb-8">
        <Link to="/" className="flex items-center">
          <span className="text-2xl font-bold text-primary-600">SkillShare</span>
        </Link>
      </div>

      <nav className="flex-1 px-3">
        <ul className="space-y-1">
          {navigationItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <li key={item.name}>
                <Link
                  to={item.path}
                  className={`flex items-center px-3 py-3 rounded-lg text-sm font-medium group relative ${
                    isActive
                      ? 'text-primary-600 bg-primary-50'
                      : 'text-neutral-700 hover:text-primary-600 hover:bg-neutral-100'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="sidebar-active-background"
                      className="absolute inset-0 bg-primary-50 rounded-lg"
                      initial={false}
                      transition={{ type: 'spring', duration: 0.5 }}
                    />
                  )}
                  <item.icon className={`h-5 w-5 mr-3 ${isActive ? 'text-primary-600' : 'text-neutral-500 group-hover:text-primary-600'}`} />
                  <span className="relative">{item.name}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {user && (
        <div className="mt-auto px-6 py-4 border-t border-neutral-200">
          <div className="flex items-center">
            <img
              src={user.avatarUrl}
              alt={user.name}
              className="h-10 w-10 rounded-full object-cover"
            />
            <div className="ml-3">
              <p className="text-sm font-medium text-neutral-800">{user.name}</p>
              <p className="text-xs text-neutral-500">@{user.username}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;