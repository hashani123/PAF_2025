import { Calendar, CheckCircle, Circle } from 'lucide-react';
import { formatDate } from '../../data/mockData';
import { LearningPlan } from '../../data/mockData';
import { motion } from 'framer-motion';

interface LearningPlanCardProps {
  plan: LearningPlan;
}

const LearningPlanCard = ({ plan }: LearningPlanCardProps) => {
  const completedMilestones = plan.milestones.filter(m => m.isCompleted).length;
  const totalMilestones = plan.milestones.length;
  
  return (
    <motion.div 
      className="bg-white rounded-xl border border-neutral-200 overflow-hidden mb-4 shadow-sm"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="px-5 py-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold text-neutral-900">{plan.title}</h3>
          <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-neutral-100 text-neutral-800">
            {plan.category}
          </span>
        </div>
        
        <p className="text-neutral-700 text-sm mb-4">{plan.description}</p>
        
        <div className="flex items-center text-sm text-neutral-500 mb-4">
          <Calendar className="h-4 w-4 mr-1" />
          <span>{formatDate(plan.startDate)} - {formatDate(plan.endDate)}</span>
        </div>
        
        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm font-medium text-neutral-700">Progress</span>
            <span className="text-sm text-neutral-500">{plan.progress}%</span>
          </div>
          <div className="w-full bg-neutral-200 rounded-full h-2.5">
            <motion.div 
              className="bg-success-500 h-2.5 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${plan.progress}%` }}
              transition={{ duration: 0.5, ease: "easeOut" }}
            />
          </div>
        </div>
        
        {/* Milestones */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <h4 className="text-sm font-medium text-neutral-700">Milestones</h4>
            <span className="text-xs text-neutral-500">{completedMilestones}/{totalMilestones} completed</span>
          </div>
          <ul className="space-y-2">
            {plan.milestones.slice(0, 3).map(milestone => (
              <li key={milestone.id} className="flex items-start">
                {milestone.isCompleted ? (
                  <CheckCircle className="h-5 w-5 text-success-500 mr-2 flex-shrink-0" />
                ) : (
                  <Circle className="h-5 w-5 text-neutral-300 mr-2 flex-shrink-0" />
                )}
                <div className="flex-1">
                  <p className={`text-sm ${milestone.isCompleted ? 'text-neutral-500 line-through' : 'text-neutral-800'}`}>
                    {milestone.title}
                  </p>
                  <p className="text-xs text-neutral-500">Due: {formatDate(milestone.dueDate)}</p>
                </div>
              </li>
            ))}
          </ul>
          
          {plan.milestones.length > 3 && (
            <button className="text-primary-600 text-sm font-medium mt-2 hover:text-primary-700">
              Show all milestones
            </button>
          )}
        </div>
      </div>
      
      {/* Actions */}
      <div className="px-5 py-3 bg-neutral-50 border-t border-neutral-200 flex justify-between">
        <button className="text-sm font-medium text-primary-600 hover:text-primary-700">
          Update Progress
        </button>
        <button className="text-sm font-medium text-neutral-600 hover:text-neutral-700">
          Edit Plan
        </button>
      </div>
    </motion.div>
  );
};

export default LearningPlanCard;