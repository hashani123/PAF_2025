import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, MessageCircle, Bookmark, Share2, MoreHorizontal } from 'lucide-react';
import { formatDate } from '../../data/mockData';
import { Post } from '../../data/mockData';
import { motion } from 'framer-motion';

interface PostCardProps {
  post: Post;
}

const PostCard = ({ post }: PostCardProps) => {
  const [isLiked, setIsLiked] = useState(post.isLiked || false);
  const [likeCount, setLikeCount] = useState(post.likes);
  const [isBookmarked, setIsBookmarked] = useState(false);

  const handleLike = () => {
    if (isLiked) {
      setLikeCount(prev => prev - 1);
    } else {
      setLikeCount(prev => prev + 1);
    }
    setIsLiked(!isLiked);
  };

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
  };

  return (
    <motion.div 
      className="bg-white rounded-xl border border-neutral-200 overflow-hidden mb-4 shadow-sm"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {/* Post Header */}
      <div className="px-4 pt-4 flex items-center justify-between">
        <Link to={`/profile/${post.userId}`} className="flex items-center">
          <img 
            src={post.userAvatar} 
            alt={post.userName} 
            className="h-10 w-10 rounded-full object-cover border border-neutral-200"
          />
          <div className="ml-3">
            <p className="font-medium text-neutral-900">{post.userName}</p>
            <p className="text-xs text-neutral-500">{formatDate(post.createdAt)}</p>
          </div>
        </Link>
        <button className="text-neutral-400 hover:text-neutral-600 p-1 rounded-full hover:bg-neutral-100">
          <MoreHorizontal className="h-5 w-5" />
        </button>
      </div>

      {/* Post Content */}
      <div className="px-4 pt-3">
        <Link to={`/post/${post.id}`}>
          <h2 className="text-lg font-semibold text-neutral-900 mb-2">{post.title}</h2>
          <p className="text-neutral-700 mb-3">
            {post.content.length > 150 ? `${post.content.substring(0, 150)}...` : post.content}
          </p>
        </Link>
      </div>

      {/* Post Media */}
      {post.mediaUrls.length > 0 && (
        <div className={`mt-2 ${post.mediaUrls.length > 1 ? 'grid grid-cols-2 gap-1' : ''}`}>
          {post.mediaUrls.map((media, index) => (
            <img
              key={index}
              src={media}
              alt={`${post.title} media ${index + 1}`}
              className={`w-full h-60 object-cover ${post.mediaUrls.length === 1 ? '' : 'h-44'}`}
            />
          ))}
        </div>
      )}

      {/* Post category */}
      <div className="px-4 mt-3">
        <span className="inline-block bg-neutral-100 text-neutral-800 rounded-full px-3 py-1 text-xs font-medium">
          {post.category}
        </span>
      </div>

      {/* Post Actions */}
      <div className="px-4 py-3 flex items-center justify-between border-t border-neutral-100 mt-3">
        <div className="flex space-x-5">
          <button 
            onClick={handleLike}
            className={`flex items-center space-x-1 ${isLiked ? 'text-error-500' : 'text-neutral-600'}`}
          >
            <Heart className={`h-5 w-5 ${isLiked ? 'fill-current' : ''}`} />
            <span className="text-sm">{likeCount}</span>
          </button>
          <Link to={`/post/${post.id}`} className="flex items-center space-x-1 text-neutral-600">
            <MessageCircle className="h-5 w-5" />
            <span className="text-sm">{post.comments}</span>
          </Link>
        </div>
        <div className="flex space-x-4">
          <button 
            onClick={handleBookmark}
            className={`p-1 rounded-full ${isBookmarked ? 'text-accent-500' : 'text-neutral-500 hover:text-neutral-700'}`}
          >
            <Bookmark className={`h-5 w-5 ${isBookmarked ? 'fill-current' : ''}`} />
          </button>
          <button className="p-1 rounded-full text-neutral-500 hover:text-neutral-700">
            <Share2 className="h-5 w-5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default PostCard;