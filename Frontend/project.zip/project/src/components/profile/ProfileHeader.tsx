import { User } from '../../context/AuthContext';
import { motion } from 'framer-motion';
import Button from '../common/Button';
import { useAuth } from '../../context/AuthContext';
import { UserPlus, Bell, Edit } from 'lucide-react';

interface ProfileHeaderProps {
  user: User;
}

const ProfileHeader = ({ user }: ProfileHeaderProps) => {
  const { user: currentUser } = useAuth();
  const isCurrentUser = currentUser?.id === user.id;
  const [isFollowing, setIsFollowing] = useState(false);

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
  };

  return (
    <div className="bg-white rounded-xl border border-neutral-200 overflow-hidden mb-6 shadow-sm">
      {/* Cover photo */}
      <div className="h-40 bg-gradient-to-r from-primary-600 to-secondary-500"></div>
      
      {/* Profile info */}
      <div className="px-6 py-5 relative">
        {/* Avatar */}
        <div className="absolute -top-16 left-6 border-4 border-white rounded-full">
          <motion.img 
            src={user.avatarUrl} 
            alt={user.name}
            className="h-24 w-24 rounded-full object-cover"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
          />
        </div>
        
        {/* Actions */}
        <div className="flex justify-end mb-12">
          {isCurrentUser ? (
            <Button 
              variant="outline" 
              size="sm" 
              icon={<Edit className="h-4 w-4" />}
            >
              Edit Profile
            </Button>
          ) : (
            <div className="flex space-x-2">
              <Button
                variant={isFollowing ? "outline" : "primary"}
                size="sm"
                icon={isFollowing ? <Bell className="h-4 w-4" /> : <UserPlus className="h-4 w-4" />}
                onClick={handleFollow}
              >
                {isFollowing ? 'Following' : 'Follow'}
              </Button>
            </div>
          )}
        </div>
        
        {/* User info */}
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">{user.name}</h1>
          <p className="text-neutral-500 mb-3">@{user.username}</p>
          <p className="text-neutral-700 mb-4">{user.bio}</p>
          
          <div className="flex space-x-4">
            <div className="text-center">
              <span className="font-semibold text-neutral-900">{user.following}</span>
              <p className="text-sm text-neutral-500">Following</p>
            </div>
            <div className="text-center">
              <span className="font-semibold text-neutral-900">{user.followers}</span>
              <p className="text-sm text-neutral-500">Followers</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;

// Add this import to prevent TypeScript errors
import { useState } from 'react';