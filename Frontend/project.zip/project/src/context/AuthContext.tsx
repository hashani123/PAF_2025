import { createContext, useContext, useState, ReactNode } from 'react';

// Mock user type
export type User = {
  id: string;
  name: string;
  username: string;
  avatarUrl: string;
  bio: string;
  following: number;
  followers: number;
};

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: () => void;
  logout: () => void;
}

// Mock user data
const mockUser: User = {
  id: '1',
  name: 'Alex Johnson',
  username: 'alexj',
  avatarUrl: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg',
  bio: 'Frontend developer with a passion for UX/UI design. Love to share my learning journey!',
  following: 124,
  followers: 325,
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(mockUser); // For demo purposes, start logged in

  const login = () => {
    // Mock login function - in real implementation this would authenticate with OAuth
    setUser(mockUser);
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}