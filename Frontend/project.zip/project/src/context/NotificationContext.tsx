import { createContext, useContext, useState, ReactNode } from 'react';

export type Notification = {
  id: string;
  type: 'like' | 'comment' | 'follow';
  message: string;
  fromUser: {
    id: string;
    name: string;
    avatarUrl: string;
  };
  postId?: string;
  read: boolean;
  createdAt: Date;
};

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
}

// Mock notification data
const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'like',
    message: 'liked your post about UI design basics',
    fromUser: {
      id: '2',
      name: 'Sarah Miller',
      avatarUrl: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg',
    },
    postId: '101',
    read: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
  },
  {
    id: '2',
    type: 'comment',
    message: 'commented on your learning plan',
    fromUser: {
      id: '3',
      name: 'David Chen',
      avatarUrl: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg',
    },
    postId: '102',
    read: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
  },
  {
    id: '3',
    type: 'follow',
    message: 'started following you',
    fromUser: {
      id: '4',
      name: 'Emily Davis',
      avatarUrl: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
    },
    read: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
  },
];

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);

  const unreadCount = notifications.filter(notification => !notification.read).length;

  const markAsRead = (id: string) => {
    setNotifications(prevNotifications =>
      prevNotifications.map(notification =>
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prevNotifications =>
      prevNotifications.map(notification => ({ ...notification, read: true }))
    );
  };

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        markAsRead,
        markAllAsRead,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
}