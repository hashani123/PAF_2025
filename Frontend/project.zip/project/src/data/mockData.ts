import { format } from 'date-fns';

// Post types
export type Post = {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  title: string;
  content: string;
  mediaUrls: string[];
  likes: number;
  comments: number;
  createdAt: Date;
  category: string;
  isLiked?: boolean;
};

export type Comment = {
  id: string;
  postId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  createdAt: Date;
};

export type LearningPlan = {
  id: string;
  userId: string;
  title: string;
  description: string;
  milestones: LearningMilestone[];
  progress: number; // 0-100
  startDate: Date;
  endDate: Date;
  category: string;
};

export type LearningMilestone = {
  id: string;
  title: string;
  isCompleted: boolean;
  dueDate: Date;
};

// Mock posts data
export const posts: Post[] = [
  {
    id: '1',
    userId: '2',
    userName: 'Sarah Miller',
    userAvatar: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg',
    title: 'Getting Started with React Hooks',
    content: "I've been learning React Hooks for the past month and wanted to share my experience. Hooks have revolutionized how I build components by allowing me to reuse stateful logic without changing component hierarchy. Here's a quick guide on useState and useEffect...",
    mediaUrls: [
      'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg',
      'https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg'
    ],
    likes: 42,
    comments: 8,
    createdAt: new Date(2023, 5, 15),
    category: 'Programming',
    isLiked: true,
  },
  {
    id: '2',
    userId: '3',
    userName: 'David Chen',
    userAvatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg',
    title: 'My Photography Journey',
    content: "It's been six months since I started learning photography, and I'm excited to share my progress. I've learned about composition, lighting, and post-processing. These photos were taken during my recent trip to the mountains...",
    mediaUrls: [
      'https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg',
      'https://images.pexels.com/photos/371589/pexels-photo-371589.jpeg',
      'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg'
    ],
    likes: 87,
    comments: 15,
    createdAt: new Date(2023, 5, 20),
    category: 'Photography',
  },
  {
    id: '3',
    userId: '4',
    userName: 'Emily Davis',
    userAvatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
    title: 'Homemade Sourdough Recipe',
    content: "After months of practice, I finally perfected my sourdough bread recipe! The key was maintaining the right starter temperature and developing patience during the fermentation process. Here's my step-by-step guide...",
    mediaUrls: [
      'https://images.pexels.com/photos/1756061/pexels-photo-1756061.jpeg',
    ],
    likes: 124,
    comments: 37,
    createdAt: new Date(2023, 6, 5),
    category: 'Cooking',
  },
];

// Mock comments
export const comments: Comment[] = [
  {
    id: '1',
    postId: '1',
    userId: '3',
    userName: 'David Chen',
    userAvatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg',
    content: "Great explanation! I've been struggling with understanding useEffect dependencies. This really cleared things up for me.",
    createdAt: new Date(2023, 5, 16, 14, 35),
  },
  {
    id: '2',
    postId: '1',
    userId: '4',
    userName: 'Emily Davis',
    userAvatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
    content: 'Have you tried the useContext hook? I found it really useful for managing global state without prop drilling.',
    createdAt: new Date(2023, 5, 16, 15, 12),
  },
  {
    id: '3',
    postId: '2',
    userId: '1',
    userName: 'Alex Johnson',
    userAvatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg',
    content: 'These photos are stunning! What camera and lens did you use for the mountain shots?',
    createdAt: new Date(2023, 5, 21, 9, 44),
  },
];

// Mock learning plans
export const learningPlans: LearningPlan[] = [
  {
    id: '1',
    userId: '1',
    title: 'Advanced React and TypeScript',
    description: 'This is my 3-month plan to master advanced React patterns and TypeScript to enhance my frontend development skills.',
    milestones: [
      {
        id: 'm1',
        title: 'Learn React Hooks in depth',
        isCompleted: true,
        dueDate: new Date(2023, 6, 15),
      },
      {
        id: 'm2',
        title: 'Master TypeScript generics and utility types',
        isCompleted: false,
        dueDate: new Date(2023, 7, 15),
      },
      {
        id: 'm3',
        title: 'Build a full-stack project with Next.js',
        isCompleted: false,
        dueDate: new Date(2023, 8, 15),
      },
    ],
    progress: 33,
    startDate: new Date(2023, 5, 15),
    endDate: new Date(2023, 8, 15),
    category: 'Programming',
  },
  {
    id: '2',
    userId: '1',
    title: 'Digital Photography Fundamentals',
    description: 'My journey to learn photography basics, from camera settings to composition techniques.',
    milestones: [
      {
        id: 'm4',
        title: 'Learn exposure triangle (aperture, shutter speed, ISO)',
        isCompleted: true,
        dueDate: new Date(2023, 4, 10),
      },
      {
        id: 'm5',
        title: 'Master composition rules',
        isCompleted: true,
        dueDate: new Date(2023, 5, 20),
      },
      {
        id: 'm6',
        title: 'Learn basic photo editing in Lightroom',
        isCompleted: false,
        dueDate: new Date(2023, 6, 30),
      },
    ],
    progress: 66,
    startDate: new Date(2023, 3, 1),
    endDate: new Date(2023, 6, 30),
    category: 'Photography',
  },
];

// Utility functions
export const formatDate = (date: Date): string => {
  return format(date, 'MMM d, yyyy');
};

export const formatDateTime = (date: Date): string => {
  return format(date, 'MMM d, yyyy h:mm a');
};