import { useState, ChangeEvent } from 'react';
import { X, Upload, Image, Film, Paperclip } from 'lucide-react';
import Button from '../components/common/Button';
import Card from '../components/common/Card';

const CreatePostPage = () => {
  const [postTitle, setPostTitle] = useState('');
  const [postContent, setPostContent] = useState('');
  const [category, setCategory] = useState('');
  const [mediaFiles, setMediaFiles] = useState<File[]>([]);
  const [mediaPreviews, setMediaPreviews] = useState<string[]>([]);

  const categories = [
    'Programming', 'Design', 'Photography',
    'Cooking', 'Fitness', 'Music',
    'Languages', 'Art', 'Finance',
    'Writing', 'Science', 'Other'
  ];

  const handleMediaChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files).slice(0, 3 - mediaFiles.length);
      setMediaFiles([...mediaFiles, ...newFiles]);
      
      // Create preview URLs
      const newPreviews = newFiles.map(file => URL.createObjectURL(file));
      setMediaPreviews([...mediaPreviews, ...newPreviews]);
    }
  };

  const removeMedia = (index: number) => {
    // Clean up URL to prevent memory leaks
    URL.revokeObjectURL(mediaPreviews[index]);
    
    setMediaFiles(mediaFiles.filter((_, i) => i !== index));
    setMediaPreviews(mediaPreviews.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real application, this would send data to your backend
    console.log({
      title: postTitle,
      content: postContent,
      category,
      mediaFiles
    });
    
    // Reset form
    setPostTitle('');
    setPostContent('');
    setCategory('');
    
    // Clean up URL objects
    mediaPreviews.forEach(url => URL.revokeObjectURL(url));
    setMediaFiles([]);
    setMediaPreviews([]);
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Create Post</h1>
      
      <Card>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="postTitle" className="block text-sm font-medium text-neutral-700 mb-1">
              Title
            </label>
            <input
              id="postTitle"
              type="text"
              value={postTitle}
              onChange={(e) => setPostTitle(e.target.value)}
              className="w-full border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder="Give your post a title"
              maxLength={100}
              required
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="postContent" className="block text-sm font-medium text-neutral-700 mb-1">
              Description
            </label>
            <textarea
              id="postContent"
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              className="w-full border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder="Share details about what you're learning or teaching..."
              rows={6}
              required
            />
          </div>
          
          <div className="mb-4">
            <label htmlFor="category" className="block text-sm font-medium text-neutral-700 mb-1">
              Category
            </label>
            <select
              id="category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full border border-neutral-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              required
            >
              <option value="" disabled>Select a category</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
          
          {/* Media preview */}
          {mediaPreviews.length > 0 && (
            <div className="mb-4 grid grid-cols-3 gap-2">
              {mediaPreviews.map((preview, index) => (
                <div key={index} className="relative group">
                  <img
                    src={preview}
                    alt={`Preview ${index}`}
                    className="h-32 w-full object-cover rounded-lg border border-neutral-200"
                  />
                  <button
                    type="button"
                    onClick={() => removeMedia(index)}
                    className="absolute top-1 right-1 bg-neutral-800 bg-opacity-70 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
          
          {/* Media upload */}
          {mediaFiles.length < 3 && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-neutral-700 mb-1">
                Add Media (up to 3)
              </label>
              <div className="flex space-x-2">
                <label className="cursor-pointer flex-1">
                  <div className="flex items-center justify-center border-2 border-dashed border-neutral-300 rounded-lg p-4 hover:border-primary-500 transition-colors">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleMediaChange}
                      className="hidden"
                    />
                    <div className="text-center">
                      <Image className="h-6 w-6 mx-auto text-neutral-500" />
                      <span className="block mt-1 text-sm text-neutral-500">Add Image</span>
                    </div>
                  </div>
                </label>
                
                <label className="cursor-pointer flex-1">
                  <div className="flex items-center justify-center border-2 border-dashed border-neutral-300 rounded-lg p-4 hover:border-primary-500 transition-colors">
                    <input
                      type="file"
                      accept="video/*"
                      onChange={handleMediaChange}
                      className="hidden"
                    />
                    <div className="text-center">
                      <Film className="h-6 w-6 mx-auto text-neutral-500" />
                      <span className="block mt-1 text-sm text-neutral-500">Add Video</span>
                    </div>
                  </div>
                </label>
                
                <label className="cursor-pointer flex-1">
                  <div className="flex items-center justify-center border-2 border-dashed border-neutral-300 rounded-lg p-4 hover:border-primary-500 transition-colors">
                    <input
                      type="file"
                      onChange={handleMediaChange}
                      className="hidden"
                    />
                    <div className="text-center">
                      <Paperclip className="h-6 w-6 mx-auto text-neutral-500" />
                      <span className="block mt-1 text-sm text-neutral-500">Attach File</span>
                    </div>
                  </div>
                </label>
              </div>
              <p className="mt-1 text-xs text-neutral-500">
                Supported formats: JPEG, PNG, GIF, MP4, PDF (max 10MB each)
              </p>
            </div>
          )}
          
          <div className="flex justify-end">
            <Button type="button" variant="outline" className="mr-2">
              Cancel
            </Button>
            <Button type="submit" disabled={!postTitle || !postContent || !category}>
              Publish Post
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default CreatePostPage;