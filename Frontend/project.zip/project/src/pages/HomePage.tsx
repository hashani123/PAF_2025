import { useState, useEffect } from 'react';
import PostCard from '../components/posts/PostCard';
import Card from '../components/common/Card';
import { posts } from '../data/mockData';
import { User, Zap, Sparkles, TrendingUp } from 'lucide-react';

const HomePage = () => {
  const [feed, setFeed] = useState(posts);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="md:col-span-2">
        <h1 className="text-2xl font-bold mb-6">Home Feed</h1>

        {/* Feed filters */}
        <div className="flex overflow-x-auto mb-6 py-1 gap-2">
          <button className="flex items-center px-4 py-2 bg-primary-600 text-white rounded-full text-sm font-medium">
            <Zap className="h-4 w-4 mr-1.5" />
            For You
          </button>
          <button className="flex items-center px-4 py-2 bg-white text-neutral-700 rounded-full text-sm font-medium border border-neutral-200 hover:bg-neutral-50">
            <Sparkles className="h-4 w-4 mr-1.5" />
            Following
          </button>
          <button className="flex items-center px-4 py-2 bg-white text-neutral-700 rounded-full text-sm font-medium border border-neutral-200 hover:bg-neutral-50">
            <TrendingUp className="h-4 w-4 mr-1.5" />
            Trending
          </button>
        </div>

        {/* Posts feed */}
        {isLoading ? (
          // Skeleton loading
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="rounded-full bg-neutral-200 h-10 w-10"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-neutral-200 rounded w-1/4 mb-2"></div>
                    <div className="h-3 bg-neutral-200 rounded w-1/5"></div>
                  </div>
                </div>
                <div className="h-4 bg-neutral-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-neutral-200 rounded w-1/2 mb-2"></div>
                <div className="h-40 bg-neutral-200 rounded mt-3"></div>
                <div className="h-10 bg-neutral-200 rounded mt-3"></div>
              </Card>
            ))}
          </div>
        ) : (
          feed.map(post => <PostCard key={post.id} post={post} />)
        )}
      </div>

      <div className="hidden md:block">
        <div className="sticky top-6">
          {/* Who to follow */}
          <Card className="mb-6">
            <h2 className="text-lg font-semibold mb-4">Who to follow</h2>
            <div className="space-y-4">
              {[
                { id: '101', name: 'Emma Watson', username: 'emmaw', avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg' },
                { id: '102', name: 'James Rodriguez', username: 'jamesr', avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg' },
                { id: '103', name: 'Sophia Chen', username: 'sophiac', avatar: 'https://images.pexels.com/photos/1542085/pexels-photo-1542085.jpeg' },
              ].map(person => (
                <div key={person.id} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img src={person.avatar} alt={person.name} className="h-10 w-10 rounded-full object-cover" />
                    <div className="ml-3">
                      <p className="font-medium text-neutral-900">{person.name}</p>
                      <p className="text-xs text-neutral-500">@{person.username}</p>
                    </div>
                  </div>
                  <button className="text-xs font-medium text-primary-600 hover:text-primary-700 bg-primary-50 hover:bg-primary-100 px-2.5 py-1.5 rounded-full">
                    Follow
                  </button>
                </div>
              ))}
            </div>
            <button className="w-full mt-4 text-primary-600 text-sm font-medium hover:text-primary-700">
              Show more
            </button>
          </Card>

          {/* Trending skills */}
          <Card>
            <h2 className="text-lg font-semibold mb-4">Trending Skills</h2>
            <div className="space-y-3">
              {[
                { tag: 'UIDesign', count: 2453 },
                { tag: 'ReactJS', count: 1892 },
                { tag: 'Photography', count: 1256 },
                { tag: 'MachineLearning', count: 986 },
                { tag: 'Cooking', count: 762 },
              ].map(trend => (
                <div key={trend.tag} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-neutral-800">#{trend.tag}</p>
                    <p className="text-xs text-neutral-500">{trend.count} posts</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default HomePage;