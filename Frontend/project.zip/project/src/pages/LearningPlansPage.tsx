import { useState } from 'react';
import LearningPlanCard from '../components/learning/LearningPlanCard';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { learningPlans } from '../data/mockData';
import { Plus, CheckCircle2, Clock } from 'lucide-react';

const LearningPlansPage = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'active' | 'completed'>('all');
  
  // Filter plans based on active tab
  const filteredPlans = learningPlans.filter(plan => {
    if (activeTab === 'all') return true;
    if (activeTab === 'active') return plan.progress < 100;
    if (activeTab === 'completed') return plan.progress === 100;
    return true;
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Learning Plans</h1>
        <Button icon={<Plus className="h-4 w-4" />}>
          Create New Plan
        </Button>
      </div>
      
      {/* Tab navigation */}
      <div className="flex border-b border-neutral-200 mb-6">
        <button
          className={`pb-4 px-4 text-sm font-medium border-b-2 -mb-px ${
            activeTab === 'all'
              ? 'border-primary-600 text-primary-600'
              : 'border-transparent text-neutral-600 hover:text-neutral-900'
          }`}
          onClick={() => setActiveTab('all')}
        >
          All Plans
        </button>
        <button
          className={`pb-4 px-4 text-sm font-medium border-b-2 -mb-px flex items-center ${
            activeTab === 'active'
              ? 'border-primary-600 text-primary-600'
              : 'border-transparent text-neutral-600 hover:text-neutral-900'
          }`}
          onClick={() => setActiveTab('active')}
        >
          <Clock className="h-4 w-4 mr-1.5" />
          In Progress
        </button>
        <button
          className={`pb-4 px-4 text-sm font-medium border-b-2 -mb-px flex items-center ${
            activeTab === 'completed'
              ? 'border-primary-600 text-primary-600'
              : 'border-transparent text-neutral-600 hover:text-neutral-900'
          }`}
          onClick={() => setActiveTab('completed')}
        >
          <CheckCircle2 className="h-4 w-4 mr-1.5" />
          Completed
        </button>
      </div>
      
      {/* Learning plans grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredPlans.length > 0 ? (
          filteredPlans.map(plan => (
            <LearningPlanCard key={plan.id} plan={plan} />
          ))
        ) : (
          <div className="col-span-2">
            <Card className="py-12 flex flex-col items-center justify-center text-center">
              <div className="bg-neutral-100 rounded-full p-3 mb-4">
                {activeTab === 'completed' ? (
                  <CheckCircle2 className="h-6 w-6 text-neutral-400" />
                ) : (
                  <Clock className="h-6 w-6 text-neutral-400" />
                )}
              </div>
              <h3 className="text-lg font-medium text-neutral-900 mb-2">
                {activeTab === 'all' 
                  ? "You don't have any learning plans yet" 
                  : activeTab === 'active' 
                    ? "You don't have any active learning plans" 
                    : "You don't have any completed learning plans"}
              </h3>
              <p className="text-neutral-600 mb-6 max-w-md">
                {activeTab === 'all' 
                  ? "Create your first learning plan to organize your skill development journey" 
                  : activeTab === 'active' 
                    ? "Your active learning plans will appear here" 
                    : "Keep learning and complete your plans to see them here"}
              </p>
              {activeTab === 'all' && (
                <Button icon={<Plus className="h-4 w-4" />}>
                  Create Your First Plan
                </Button>
              )}
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default LearningPlansPage;