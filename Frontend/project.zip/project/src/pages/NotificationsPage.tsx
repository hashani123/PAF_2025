import React from 'react';

const NotificationsPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Notifications</h1>
      <div className="space-y-4">
        {/* Placeholder for notifications list */}
        <p className="text-gray-600">No new notifications</p>
      </div>
    </div>
  );
};

export default NotificationsPage;