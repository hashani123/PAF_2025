import { useState } from 'react';
import { useParams } from 'react-router-dom';
import ProfileHeader from '../components/profile/ProfileHeader';
import PostCard from '../components/posts/PostCard';
import LearningPlanCard from '../components/learning/LearningPlanCard';
import { useAuth } from '../context/AuthContext';
import { posts, learningPlans } from '../data/mockData';

const ProfilePage = () => {
  const { userId } = useParams<{ userId: string }>();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'posts' | 'plans' | 'likes'>('posts');
  
  // In a real app, we would fetch user data based on userId
  const profileUser = user;
  
  // Filter posts and plans for this user
  const userPosts = posts.filter(post => post.userId === userId);
  const userPlans = learningPlans.filter(plan => plan.userId === userId);

  return (
    <div>
      {profileUser && (
        <>
          <ProfileHeader user={profileUser} />
          
          {/* Profile tabs */}
          <div className="flex border-b border-neutral-200 mb-6">
            <button
              className={`pb-4 px-4 text-sm font-medium border-b-2 -mb-px ${
                activeTab === 'posts'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-transparent text-neutral-600 hover:text-neutral-900'
              }`}
              onClick={() => setActiveTab('posts')}
            >
              Posts
            </button>
            <button
              className={`pb-4 px-4 text-sm font-medium border-b-2 -mb-px ${
                activeTab === 'plans'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-transparent text-neutral-600 hover:text-neutral-900'
              }`}
              onClick={() => setActiveTab('plans')}
            >
              Learning Plans
            </button>
            <button
              className={`pb-4 px-4 text-sm font-medium border-b-2 -mb-px ${
                activeTab === 'likes'
                  ? 'border-primary-600 text-primary-600'
                  : 'border-transparent text-neutral-600 hover:text-neutral-900'
              }`}
              onClick={() => setActiveTab('likes')}
            >
              Liked Posts
            </button>
          </div>
          
          {/* Tab content */}
          {activeTab === 'posts' && (
            <div>
              {userPosts.length > 0 ? (
                userPosts.map(post => <PostCard key={post.id} post={post} />)
              ) : (
                <div className="text-center py-12 bg-white rounded-lg border border-neutral-200">
                  <h3 className="text-lg font-medium text-neutral-900 mb-2">No posts yet</h3>
                  <p className="text-neutral-600 mb-4">This user hasn't shared any posts yet.</p>
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'plans' && (
            <div>
              {userPlans.length > 0 ? (
                <div className="grid grid-cols-1 gap-6">
                  {userPlans.map(plan => <LearningPlanCard key={plan.id} plan={plan} />)}
                </div>
              ) : (
                <div className="text-center py-12 bg-white rounded-lg border border-neutral-200">
                  <h3 className="text-lg font-medium text-neutral-900 mb-2">No learning plans</h3>
                  <p className="text-neutral-600 mb-4">This user hasn't created any learning plans yet.</p>
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'likes' && (
            <div>
              {/* We would typically show posts the user has liked */}
              <div className="text-center py-12 bg-white rounded-lg border border-neutral-200">
                <h3 className="text-lg font-medium text-neutral-900 mb-2">No liked posts</h3>
                <p className="text-neutral-600 mb-4">This user hasn't liked any posts yet.</p>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default ProfilePage;