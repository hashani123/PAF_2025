import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { SkillShareProvider } from './context/SkillShareContext';
import Layout from './components/layout/Layout';
import HomePage from './pages/HomePage';
import ProfilePage from './pages/ProfilePage';
import LearningPlanPage from './pages/LearningPlanPage';
import CreatePostPage from './pages/CreatePostPage';
import PostDetailPage from './pages/PostDetailPage';
import NotFoundPage from './pages/NotFoundPage';
import AuthPage from './pages/AuthPage';

function App() {
  return (
    <SkillShareProvider>
      <Router>
        <Routes>
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/" element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="profile/:userId" element={<ProfilePage />} />
            <Route path="learning-plan/:planId" element={<LearningPlanPage />} />
            <Route path="create-post" element={<CreatePostPage />} />
            <Route path="post/:postId" element={<PostDetailPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      </Router>
    </SkillShareProvider>
  );
}

export default App;