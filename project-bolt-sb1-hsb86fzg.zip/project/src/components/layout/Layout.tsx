import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import NotificationPanel from './NotificationPanel';
import MobileMenu from './MobileMenu';
import { useSkillShare } from '../../context/SkillShareContext';

const Layout = () => {
  const { isAuthenticated } = useSkillShare();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const toggleNotifications = () => {
    setShowNotifications(prev => !prev);
    if (showMobileMenu) setShowMobileMenu(false);
  };

  const toggleMobileMenu = () => {
    setShowMobileMenu(prev => !prev);
    if (showNotifications) setShowNotifications(false);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {isAuthenticated && (
        <>
          {/* Desktop Sidebar */}
          <div className="hidden md:flex">
            <Sidebar />
          </div>
          
          {/* Mobile Menu Overlay */}
          {showMobileMenu && (
            <MobileMenu onClose={() => setShowMobileMenu(false)} />
          )}
        </>
      )}
      
      <div className="flex flex-col flex-1 overflow-hidden">
        <Navbar 
          onNotificationClick={toggleNotifications} 
          onMenuClick={toggleMobileMenu}
        />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="container mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
      
      {/* Notification Panel */}
      {isAuthenticated && showNotifications && (
        <NotificationPanel onClose={() => setShowNotifications(false)} />
      )}
    </div>
  );
};

export default Layout;