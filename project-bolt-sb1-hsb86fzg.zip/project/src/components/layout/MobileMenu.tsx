import React from 'react';
import { Link } from 'react-router-dom';
import { X, Home, Compass, Book, Users, Bookmark, BarChart2, Settings, Plus } from 'lucide-react';
import { useSkillShare } from '../../context/SkillShareContext';

interface MobileMenuProps {
  onClose: () => void;
}

const MobileMenu: React.FC<MobileMenuProps> = ({ onClose }) => {
  const { currentUser } = useSkillShare();
  
  const navItems = [
    { name: 'Home', icon: <Home size={22} />, path: '/' },
    { name: 'Explore', icon: <Compass size={22} />, path: '/explore' },
    { name: 'Learning Plans', icon: <Book size={22} />, path: '/learning-plans' },
    { name: 'My Network', icon: <Users size={22} />, path: '/network' },
    { name: 'Saved', icon: <Bookmark size={22} />, path: '/saved' },
    { name: 'Progress', icon: <BarChart2 size={22} />, path: '/progress' }
  ];
  
  return (
    <div className="fixed inset-0 z-30 bg-black bg-opacity-50">
      <div className="fixed inset-y-0 left-0 max-w-xs w-full bg-white shadow-xl flex flex-col animate-slide-in-left">
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <Link to="/" className="text-xl font-bold text-blue-600" onClick={onClose}>
            SkillShare
          </Link>
          <button 
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-100 text-gray-500"
            aria-label="Close menu"
          >
            <X size={20} />
          </button>
        </div>
        
        {currentUser && (
          <Link 
            to={`/profile/${currentUser.id}`}
            className="flex items-center p-4 border-b border-gray-200"
            onClick={onClose}
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-10 h-10 rounded-full object-cover border border-gray-200"
            />
            <div className="ml-3">
              <p className="font-medium text-gray-900">{currentUser.name}</p>
              <p className="text-xs text-gray-500">View Profile</p>
            </div>
          </Link>
        )}
        
        <div className="flex-1 overflow-y-auto">
          <nav className="p-4 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className="flex items-center px-3 py-3 text-base font-medium text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
                onClick={onClose}
              >
                <span className="mr-4">{item.icon}</span>
                <span>{item.name}</span>
              </Link>
            ))}
          </nav>
          
          <div className="p-4 border-t border-gray-200">
            <Link
              to="/create-post"
              className="flex items-center justify-center gap-2 w-full py-3 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              onClick={onClose}
            >
              <Plus size={20} />
              <span className="font-medium">Create Post</span>
            </Link>
          </div>
        </div>
        
        <div className="p-4 border-t border-gray-200">
          <Link
            to="/settings"
            className="flex items-center px-3 py-3 text-base font-medium text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
            onClick={onClose}
          >
            <Settings size={20} className="mr-4" />
            <span>Settings</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default MobileMenu;