import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Bell, Menu, Plus, LogOut } from 'lucide-react';
import { useSkillShare } from '../../context/SkillShareContext';

interface NavbarProps {
  onNotificationClick: () => void;
  onMenuClick: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNotificationClick, onMenuClick }) => {
  const { currentUser, isAuthenticated, logout, notifications } = useSkillShare();
  const navigate = useNavigate();
  
  const unreadNotifications = notifications.filter(n => !n.isRead && n.userId === currentUser?.id);
  
  const handleLogout = () => {
    logout();
    navigate('/auth');
  };
  
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Left section: Logo and menu button (mobile) */}
          <div className="flex items-center">
            <button
              className="md:hidden mr-4 text-gray-500 hover:text-gray-700"
              onClick={onMenuClick}
              aria-label="Menu"
            >
              <Menu size={24} />
            </button>
            
            <Link to="/" className="flex items-center">
              <span className="text-xl font-bold text-blue-600">SkillShare</span>
            </Link>
          </div>
          
          {/* Middle section: Search bar */}
          <div className="hidden md:flex items-center flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={18} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search skills, topics, users..."
                className="block w-full pl-10 pr-3 py-2 rounded-full border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-50"
              />
            </div>
          </div>
          
          {/* Right section: Actions and profile */}
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <Link
                  to="/create-post"
                  className="hidden md:flex items-center gap-1 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-full hover:bg-blue-700 transition-colors"
                >
                  <Plus size={18} />
                  <span>Create</span>
                </Link>
                
                <button
                  className="relative p-1.5 rounded-full text-gray-500 hover:bg-gray-100 hover:text-blue-600"
                  onClick={onNotificationClick}
                  aria-label="Notifications"
                >
                  <Bell size={22} />
                  {unreadNotifications.length > 0 && (
                    <span className="absolute top-0 right-0 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs text-white">
                      {unreadNotifications.length > 9 ? '9+' : unreadNotifications.length}
                    </span>
                  )}
                </button>
                
                <div className="relative group">
                  <button className="flex items-center focus:outline-none">
                    <img
                      src={currentUser?.avatar}
                      alt={currentUser?.name}
                      className="w-8 h-8 rounded-full object-cover border border-gray-200"
                    />
                  </button>
                  
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20 hidden group-hover:block">
                    <Link
                      to={`/profile/${currentUser?.id}`}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Your Profile
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
                    >
                      <LogOut size={16} />
                      <span>Sign out</span>
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <Link
                to="/auth"
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-full hover:bg-blue-700 transition-colors"
              >
                Sign In
              </Link>
            )}
          </div>
        </div>
        
        {/* Mobile search bar */}
        <div className="md:hidden pb-3">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search skills, topics, users..."
              className="block w-full pl-10 pr-3 py-2 rounded-full border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-50"
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;