import React from 'react';
import { Link } from 'react-router-dom';
import { X, Heart, MessageSquare, UserPlus, AtSign } from 'lucide-react';
import { useSkillShare } from '../../context/SkillShareContext';
import { Notification } from '../../types';

interface NotificationPanelProps {
  onClose: () => void;
}

const NotificationPanel: React.FC<NotificationPanelProps> = ({ onClose }) => {
  const { notifications, currentUser } = useSkillShare();
  
  const userNotifications = notifications.filter(
    notification => notification.userId === currentUser?.id
  ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'like':
        return <Heart size={18} className="text-red-500" />;
      case 'comment':
        return <MessageSquare size={18} className="text-blue-500" />;
      case 'follow':
        return <UserPlus size={18} className="text-green-500" />;
      case 'mention':
        return <AtSign size={18} className="text-purple-500" />;
      default:
        return null;
    }
  };
  
  const getNotificationText = (notification: Notification) => {
    const triggerUser = notification.triggeredBy;
    
    switch (notification.type) {
      case 'like':
        return <span><strong>{triggerUser}</strong> liked your post</span>;
      case 'comment':
        return <span><strong>{triggerUser}</strong> commented on your post</span>;
      case 'follow':
        return <span><strong>{triggerUser}</strong> started following you</span>;
      case 'mention':
        return <span><strong>{triggerUser}</strong> mentioned you in a comment</span>;
      default:
        return null;
    }
  };
  
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return `${diffInSeconds}s ago`;
    } else if (diffInSeconds < 3600) {
      return `${Math.floor(diffInSeconds / 60)}m ago`;
    } else if (diffInSeconds < 86400) {
      return `${Math.floor(diffInSeconds / 3600)}h ago`;
    } else {
      return `${Math.floor(diffInSeconds / 86400)}d ago`;
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-30 w-80 bg-white shadow-xl border-l border-gray-200 flex flex-col">
      <div className="px-4 py-3 border-b border-gray-200 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Notifications</h2>
        <button 
          onClick={onClose}
          className="p-1 rounded-full hover:bg-gray-100 text-gray-500"
          aria-label="Close notifications"
        >
          <X size={20} />
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {userNotifications.length > 0 ? (
          <div className="divide-y divide-gray-100">
            {userNotifications.map(notification => (
              <div 
                key={notification.id} 
                className={`p-4 transition-colors ${notification.isRead ? 'bg-white' : 'bg-blue-50'}`}
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-3 mt-0.5">
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-800">
                      {getNotificationText(notification)}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatTime(notification.createdAt)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full p-6 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <Bell size={24} className="text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">No notifications yet</h3>
            <p className="mt-1 text-sm text-gray-500">
              When someone interacts with your content, you'll see it here.
            </p>
          </div>
        )}
      </div>
      
      {userNotifications.length > 0 && (
        <div className="p-4 border-t border-gray-200">
          <Link 
            to="/notifications" 
            className="block w-full py-2 px-4 text-center text-sm font-medium text-blue-600 border border-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
            onClick={onClose}
          >
            View all notifications
          </Link>
        </div>
      )}
    </div>
  );
};

export default NotificationPanel;