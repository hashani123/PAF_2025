import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Compass, Bookmark, BarChart2, Settings, Users, Video, Book } from 'lucide-react';
import { useSkillShare } from '../../context/SkillShareContext';

const Sidebar = () => {
  const { currentUser } = useSkillShare();
  const location = useLocation();
  
  const navItems = [
    { name: 'Home', icon: <Home size={22} />, path: '/' },
    { name: 'Explore', icon: <Compass size={22} />, path: '/explore' },
    { name: 'Learning Plans', icon: <Book size={22} />, path: '/learning-plans' },
    { name: 'My Network', icon: <Users size={22} />, path: '/network' },
    { name: 'Saved', icon: <Bookmark size={22} />, path: '/saved' },
    { name: 'Progress', icon: <BarChart2 size={22} />, path: '/progress' }
  ];
  
  const categoriesItems = [
    { name: 'Programming', path: '/category/programming' },
    { name: 'Design', path: '/category/design' },
    { name: 'Photography', path: '/category/photography' },
    { name: 'Cooking', path: '/category/cooking' },
    { name: 'Languages', path: '/category/languages' }
  ];
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className="w-64 h-full bg-white border-r border-gray-200 flex flex-col">
      <div className="p-4">
        {currentUser && (
          <Link to={`/profile/${currentUser.id}`} className="flex items-center mb-6">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-10 h-10 rounded-full object-cover border border-gray-200"
            />
            <div className="ml-3">
              <p className="font-medium text-gray-900">{currentUser.name}</p>
              <p className="text-xs text-gray-500">View Profile</p>
            </div>
          </Link>
        )}
        
        <nav className="space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.name}
              to={item.path}
              className={`flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                isActive(item.path)
                  ? 'text-blue-600 bg-blue-50'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <span className="mr-3">{item.icon}</span>
              <span>{item.name}</span>
            </Link>
          ))}
        </nav>
      </div>
      
      <div className="px-4 mt-4">
        <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
          Popular Categories
        </h3>
        <div className="mt-2 space-y-1">
          {categoriesItems.map((category) => (
            <Link
              key={category.name}
              to={category.path}
              className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
            >
              {category.name}
            </Link>
          ))}
        </div>
      </div>
      
      <div className="mt-auto p-4">
        <Link
          to="/settings"
          className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <Settings size={20} className="mr-3" />
          <span>Settings</span>
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;