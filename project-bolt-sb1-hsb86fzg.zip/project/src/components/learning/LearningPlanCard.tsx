import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, ChevronRight } from 'lucide-react';
import { LearningPlan } from '../../types';
import { formatTimeAgo } from '../../utils/dateUtils';
import { mockUsers } from '../../data/mockData';

interface LearningPlanCardProps {
  plan: LearningPlan;
}

const LearningPlanCard: React.FC<LearningPlanCardProps> = ({ plan }) => {
  const user = mockUsers.find(u => u.id === plan.userId);
  
  const completedMilestones = plan.milestones.filter(m => m.isCompleted).length;
  const totalMilestones = plan.milestones.length;
  
  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center">
            <Link to={`/profile/${plan.userId}`}>
              <img
                src={user?.avatar}
                alt={user?.name}
                className="w-8 h-8 rounded-full object-cover border border-gray-200"
              />
            </Link>
            <div className="ml-2">
              <Link 
                to={`/profile/${plan.userId}`}
                className="text-sm font-medium text-gray-900 hover:text-blue-600"
              >
                {user?.name}
              </Link>
              <div className="flex items-center text-xs text-gray-500">
                <Clock size={12} className="mr-1" />
                <span>{formatTimeAgo(plan.createdAt)}</span>
              </div>
            </div>
          </div>
          <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
            {plan.category}
          </span>
        </div>
        
        <Link to={`/learning-plan/${plan.id}`}>
          <h3 className="text-lg font-semibold text-gray-900 mb-2 hover:text-blue-600 transition-colors">
            {plan.title}
          </h3>
        </Link>
        
        <p className="text-gray-700 text-sm mb-4 line-clamp-2">
          {plan.description}
        </p>
        
        <div className="mb-4">
          <div className="flex items-center justify-between text-sm mb-1.5">
            <span className="text-gray-600">Progress</span>
            <span className="font-medium">{plan.currentProgress}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-blue-600 h-2.5 rounded-full" 
              style={{ width: `${plan.currentProgress}%` }}
            ></div>
          </div>
        </div>
        
        <div className="flex items-center justify-between text-sm text-gray-600">
          <span>
            {completedMilestones} of {totalMilestones} milestones completed
          </span>
          <span>{plan.duration} days</span>
        </div>
      </div>
      
      <Link 
        to={`/learning-plan/${plan.id}`}
        className="flex items-center justify-center py-3 border-t border-gray-100 text-blue-600 hover:bg-blue-50 transition-colors group"
      >
        <span className="font-medium">View Plan</span>
        <ChevronRight 
          size={16} 
          className="ml-1 transition-transform group-hover:translate-x-1" 
        />
      </Link>
    </div>
  );
};

export default LearningPlanCard;