import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Send } from 'lucide-react';
import { Comment } from '../../types';
import { useSkillShare } from '../../context/SkillShareContext';
import { formatTimeAgo } from '../../utils/dateUtils';
import { mockUsers } from '../../data/mockData';

interface CommentSectionProps {
  postId: string;
  comments: Comment[];
}

const CommentSection: React.FC<CommentSectionProps> = ({ postId, comments }) => {
  const { currentUser, addComment } = useSkillShare();
  const [commentText, setCommentText] = useState('');
  
  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim() === '') return;
    
    addComment(postId, commentText);
    setCommentText('');
  };
  
  return (
    <div className="border-t border-gray-100 px-4 py-3">
      {/* Comment Input */}
      <form onSubmit={handleSubmitComment} className="flex items-center mb-4">
        <img
          src={currentUser?.avatar}
          alt={currentUser?.name}
          className="w-8 h-8 rounded-full object-cover border border-gray-200 mr-3"
        />
        <div className="flex-1 relative">
          <input
            type="text"
            placeholder="Add a comment..."
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            className="w-full p-2 pr-10 rounded-full bg-gray-100 border-none focus:ring-2 focus:ring-blue-500 text-sm"
          />
          <button
            type="submit"
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-blue-600 hover:text-blue-700"
            disabled={commentText.trim() === ''}
            aria-label="Post comment"
          >
            <Send size={18} />
          </button>
        </div>
      </form>
      
      {/* Comments List */}
      <div className="space-y-3">
        {comments.length > 0 ? (
          comments.map((comment) => {
            const commentUser = mockUsers.find(u => u.id === comment.userId);
            
            return (
              <div key={comment.id} className="flex items-start">
                <Link to={`/profile/${comment.userId}`}>
                  <img
                    src={commentUser?.avatar}
                    alt={commentUser?.name}
                    className="w-8 h-8 rounded-full object-cover border border-gray-200 mr-3"
                  />
                </Link>
                <div className="flex-1 bg-gray-100 rounded-lg px-3 py-2">
                  <div className="flex items-baseline justify-between">
                    <Link 
                      to={`/profile/${comment.userId}`}
                      className="font-medium text-gray-900 text-sm"
                    >
                      {commentUser?.name}
                    </Link>
                    <span className="text-xs text-gray-500 ml-2">
                      {formatTimeAgo(comment.createdAt)}
                    </span>
                  </div>
                  <p className="text-gray-700 text-sm mt-1">{comment.content}</p>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center text-gray-500 text-sm py-2">
            No comments yet. Be the first to comment!
          </div>
        )}
      </div>
    </div>
  );
};

export default CommentSection;