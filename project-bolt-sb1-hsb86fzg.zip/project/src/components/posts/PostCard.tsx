import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, MessageSquare, Share2, Bookmark, MoreHorizontal } from 'lucide-react';
import { Post } from '../../types';
import { useSkillShare } from '../../context/SkillShareContext';
import CommentSection from './CommentSection';
import { formatTimeAgo } from '../../utils/dateUtils';

interface PostCardProps {
  post: Post;
}

const PostCard: React.FC<PostCardProps> = ({ post }) => {
  const { currentUser, likePost } = useSkillShare();
  const [showComments, setShowComments] = useState(false);
  
  const isLiked = currentUser ? post.likes.includes(currentUser.id) : false;
  
  const handleLikeClick = () => {
    likePost(post.id);
  };
  
  const toggleComments = () => {
    setShowComments(prev => !prev);
  };
  
  const user = mockUsers.find(u => u.id === post.userId);
  
  if (!user) return null;
  
  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden mb-4 transition-shadow hover:shadow-md">
      {/* Post Header */}
      <div className="flex items-center justify-between p-4">
        <Link to={`/profile/${user.id}`} className="flex items-center">
          <img
            src={user.avatar}
            alt={user.name}
            className="w-10 h-10 rounded-full object-cover border border-gray-200"
          />
          <div className="ml-3">
            <p className="font-medium text-gray-900">{user.name}</p>
            <p className="text-xs text-gray-500">{formatTimeAgo(post.createdAt)}</p>
          </div>
        </Link>
        <button 
          className="p-1 rounded-full hover:bg-gray-100 text-gray-500"
          aria-label="More options"
        >
          <MoreHorizontal size={20} />
        </button>
      </div>
      
      {/* Post Title */}
      <div className="px-4 mb-2">
        <h2 className="text-xl font-semibold text-gray-900">{post.title}</h2>
      </div>
      
      {/* Post Content */}
      <div className="px-4 mb-4">
        <p className="text-gray-700">{post.content}</p>
      </div>
      
      {/* Post Media */}
      {post.mediaUrls.length > 0 && (
        <div className={`grid ${post.mediaUrls.length > 1 ? 'grid-cols-2 gap-0.5' : ''}`}>
          {post.mediaUrls.map((url, index) => (
            <div 
              key={index} 
              className={`${
                post.mediaUrls.length === 1 ? 'w-full h-96' : 
                post.mediaUrls.length === 2 ? 'h-80' : 'h-64'
              } overflow-hidden`}
            >
              <img 
                src={url} 
                alt={`Post media ${index + 1}`}
                className="w-full h-full object-cover transition-transform hover:scale-105"
              />
            </div>
          ))}
        </div>
      )}
      
      {/* Post Meta */}
      <div className="px-4 py-3 border-t border-gray-100">
        <div className="flex items-center text-sm text-gray-600">
          <span>{post.likes.length} likes</span>
          <span className="mx-2">•</span>
          <span>{post.comments.length} comments</span>
        </div>
      </div>
      
      {/* Post Actions */}
      <div className="flex items-center px-4 py-3 border-t border-gray-100">
        <button 
          className={`flex items-center mr-6 ${
            isLiked ? 'text-red-500' : 'text-gray-600 hover:text-red-500'
          }`}
          onClick={handleLikeClick}
          aria-label={isLiked ? 'Unlike' : 'Like'}
        >
          <Heart 
            size={20} 
            className={`mr-1.5 ${isLiked ? 'fill-current' : ''}`} 
          />
          <span>Like</span>
        </button>
        
        <button 
          className="flex items-center mr-6 text-gray-600 hover:text-blue-500"
          onClick={toggleComments}
          aria-label="Comment"
        >
          <MessageSquare size={20} className="mr-1.5" />
          <span>Comment</span>
        </button>
        
        <button 
          className="flex items-center mr-6 text-gray-600 hover:text-green-500"
          aria-label="Share"
        >
          <Share2 size={20} className="mr-1.5" />
          <span>Share</span>
        </button>
        
        <button 
          className="flex items-center text-gray-600 hover:text-purple-500 ml-auto"
          aria-label="Save"
        >
          <Bookmark size={20} className="mr-1.5" />
          <span>Save</span>
        </button>
      </div>
      
      {/* Comments Section */}
      {showComments && (
        <CommentSection postId={post.id} comments={post.comments} />
      )}
    </div>
  );
};

export default PostCard;

// Import at the top of the file
import { mockUsers } from '../../data/mockData';