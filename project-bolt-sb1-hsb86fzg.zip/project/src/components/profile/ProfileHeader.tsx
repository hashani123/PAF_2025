import React from 'react';
import { UserPlus, Check, Mail, Link as LinkIcon, MapPin } from 'lucide-react';
import { User } from '../../types';
import { useSkillShare } from '../../context/SkillShareContext';

interface ProfileHeaderProps {
  user: User;
}

const ProfileHeader: React.FC<ProfileHeaderProps> = ({ user }) => {
  const { currentUser, followUser, unfollowUser } = useSkillShare();
  
  const isCurrentUser = currentUser?.id === user.id;
  const isFollowing = currentUser?.following.includes(user.id);
  
  const handleFollowToggle = () => {
    if (isFollowing) {
      unfollowUser(user.id);
    } else {
      followUser(user.id);
    }
  };
  
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
      {/* Cover Image */}
      <div className="h-48 bg-gradient-to-r from-blue-500 to-purple-600"></div>
      
      <div className="p-6">
        <div className="flex flex-col md:flex-row md:items-end">
          {/* Profile Picture */}
          <div className="relative -mt-20 md:-mt-24 mb-4 md:mb-0">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-24 h-24 md:w-32 md:h-32 rounded-full border-4 border-white object-cover"
            />
          </div>
          
          {/* Profile Info */}
          <div className="md:ml-6 flex-1">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
                <div className="flex items-center mt-1 text-gray-600">
                  <span className="text-sm">{user.followers.length} followers</span>
                  <span className="mx-2">•</span>
                  <span className="text-sm">{user.following.length} following</span>
                </div>
              </div>
              
              {!isCurrentUser && (
                <div className="mt-4 md:mt-0 flex space-x-3">
                  <button 
                    onClick={handleFollowToggle}
                    className={`px-4 py-2 rounded-full flex items-center font-medium text-sm transition-colors ${
                      isFollowing 
                        ? 'bg-gray-200 text-gray-800 hover:bg-gray-300' 
                        : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <Check size={16} className="mr-1.5" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus size={16} className="mr-1.5" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>
                  
                  <button 
                    className="px-4 py-2 rounded-full border border-gray-300 text-gray-700 hover:bg-gray-100 font-medium text-sm flex items-center transition-colors"
                  >
                    <Mail size={16} className="mr-1.5" />
                    <span>Message</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Bio */}
        <div className="mt-6">
          <p className="text-gray-700">{user.bio}</p>
        </div>
        
        {/* Skills */}
        <div className="flex flex-wrap gap-2 mt-4">
          {user.skills.map((skill, index) => (
            <span 
              key={index}
              className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm font-medium"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;