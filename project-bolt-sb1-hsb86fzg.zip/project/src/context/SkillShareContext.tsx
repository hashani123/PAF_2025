import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Post, LearningPlan, Notification } from '../types';
import { mockUsers, mockPosts, mockLearningPlans, mockNotifications } from '../data/mockData';

interface SkillShareContextType {
  currentUser: User | null;
  posts: Post[];
  learningPlans: LearningPlan[];
  notifications: Notification[];
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  createPost: (post: Omit<Post, 'id' | 'createdAt' | 'userId' | 'likes' | 'comments'>) => void;
  likePost: (postId: string) => void;
  addComment: (postId: string, content: string) => void;
  followUser: (userId: string) => void;
  unfollowUser: (userId: string) => void;
  createLearningPlan: (plan: Omit<LearningPlan, 'id' | 'createdAt' | 'userId'>) => void;
  updateLearningProgress: (planId: string, progress: number) => void;
}

const SkillShareContext = createContext<SkillShareContextType | undefined>(undefined);

export const useSkillShare = () => {
  const context = useContext(SkillShareContext);
  if (context === undefined) {
    throw new Error('useSkillShare must be used within a SkillShareProvider');
  }
  return context;
};

interface SkillShareProviderProps {
  children: ReactNode;
}

export const SkillShareProvider = ({ children }: SkillShareProviderProps) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [learningPlans, setLearningPlans] = useState<LearningPlan[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Initialize with mock data
  useEffect(() => {
    setPosts(mockPosts);
    setLearningPlans(mockLearningPlans);
    setNotifications(mockNotifications);

    // Auto-login for demo purposes
    setCurrentUser(mockUsers[0]);
    setIsAuthenticated(true);
  }, []);

  const login = async (email: string, password: string) => {
    // Simulate API call
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        const user = mockUsers.find(u => u.email === email);
        if (user) {
          setCurrentUser(user);
          setIsAuthenticated(true);
          resolve();
        } else {
          throw new Error('Invalid credentials');
        }
      }, 500);
    });
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
  };

  const createPost = (postData: Omit<Post, 'id' | 'createdAt' | 'userId' | 'likes' | 'comments'>) => {
    if (!currentUser) return;
    
    const newPost: Post = {
      id: `post-${Date.now()}`,
      userId: currentUser.id,
      createdAt: new Date().toISOString(),
      likes: [],
      comments: [],
      ...postData
    };
    
    setPosts(prev => [newPost, ...prev]);
  };

  const likePost = (postId: string) => {
    if (!currentUser) return;
    
    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        const hasLiked = post.likes.includes(currentUser.id);
        
        if (hasLiked) {
          return {
            ...post,
            likes: post.likes.filter(id => id !== currentUser.id)
          };
        } else {
          return {
            ...post,
            likes: [...post.likes, currentUser.id]
          };
        }
      }
      return post;
    }));
  };

  const addComment = (postId: string, content: string) => {
    if (!currentUser) return;
    
    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        const newComment = {
          id: `comment-${Date.now()}`,
          userId: currentUser.id,
          content,
          createdAt: new Date().toISOString()
        };
        
        return {
          ...post,
          comments: [...post.comments, newComment]
        };
      }
      return post;
    }));
  };

  const followUser = (userId: string) => {
    if (!currentUser) return;
    
    setCurrentUser({
      ...currentUser,
      following: [...currentUser.following, userId]
    });
  };

  const unfollowUser = (userId: string) => {
    if (!currentUser) return;
    
    setCurrentUser({
      ...currentUser,
      following: currentUser.following.filter(id => id !== userId)
    });
  };

  const createLearningPlan = (planData: Omit<LearningPlan, 'id' | 'createdAt' | 'userId'>) => {
    if (!currentUser) return;
    
    const newPlan: LearningPlan = {
      id: `plan-${Date.now()}`,
      userId: currentUser.id,
      createdAt: new Date().toISOString(),
      ...planData
    };
    
    setLearningPlans(prev => [newPlan, ...prev]);
  };

  const updateLearningProgress = (planId: string, progress: number) => {
    setLearningPlans(prev => prev.map(plan => {
      if (plan.id === planId) {
        return {
          ...plan,
          currentProgress: progress
        };
      }
      return plan;
    }));
  };

  const value = {
    currentUser,
    posts,
    learningPlans,
    notifications,
    isAuthenticated,
    login,
    logout,
    createPost,
    likePost,
    addComment,
    followUser,
    unfollowUser,
    createLearningPlan,
    updateLearningProgress
  };

  return (
    <SkillShareContext.Provider value={value}>
      {children}
    </SkillShareContext.Provider>
  );
};