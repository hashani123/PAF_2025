import { User, Post, LearningPlan, Notification } from '../types';

export const mockUsers: User[] = [
  {
    id: 'user1',
    name: 'Alex Johnson',
    email: 'alex@example.com',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Passionate about learning and sharing web development skills.',
    skills: ['JavaScript', 'React', 'Node.js'],
    following: ['user2', 'user3'],
    followers: ['user2', 'user4'],
    joinedAt: '2023-01-15T10:00:00Z'
  },
  {
    id: 'user2',
    name: 'Sasha Chen',
    email: 'sasha@example.com',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Food photographer and cooking enthusiast.',
    skills: ['Photography', 'Cooking', 'Food Styling'],
    following: ['user1'],
    followers: ['user1', 'user3'],
    joinedAt: '2023-01-20T10:00:00Z'
  },
  {
    id: 'user3',
    name: 'Miguel Torres',
    email: 'miguel@example.com',
    avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Software engineer exploring machine learning and AI.',
    skills: ['Python', 'Machine Learning', 'AI'],
    following: ['user1'],
    followers: ['user1'],
    joinedAt: '2023-02-05T10:00:00Z'
  },
  {
    id: 'user4',
    name: 'Maya Williams',
    email: 'maya@example.com',
    avatar: 'https://images.pexels.com/photos/712513/pexels-photo-712513.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Digital artist and graphic designer teaching others to bring ideas to life.',
    skills: ['Graphic Design', 'Digital Art', 'Illustration'],
    following: ['user1', 'user2'],
    followers: [],
    joinedAt: '2023-02-15T10:00:00Z'
  }
];

export const mockPosts: Post[] = [
  {
    id: 'post1',
    userId: 'user1',
    title: 'Getting Started with React Hooks',
    content: 'Today I want to share my learning journey with React Hooks. Here are the key concepts I\'ve mastered and tips for beginners...',
    mediaUrls: [
      'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Programming',
    tags: ['react', 'javascript', 'webdev'],
    likes: ['user2', 'user3'],
    comments: [
      {
        id: 'comment1',
        userId: 'user2',
        content: 'Great explanation! This helped me understand useEffect better.',
        createdAt: '2023-03-10T15:30:00Z'
      }
    ],
    createdAt: '2023-03-10T14:00:00Z'
  },
  {
    id: 'post2',
    userId: 'user2',
    title: 'Mastering Food Photography',
    content: 'Over the past month, I\'ve been practicing food photography. Here are some techniques I\'ve learned for better composition and lighting...',
    mediaUrls: [
      'https://images.pexels.com/photos/376464/pexels-photo-376464.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/1099680/pexels-photo-1099680.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Photography',
    tags: ['foodphotography', 'cooking', 'lighting'],
    likes: ['user1', 'user4'],
    comments: [
      {
        id: 'comment2',
        userId: 'user4',
        content: 'Your photos look amazing! What camera do you use?',
        createdAt: '2023-03-15T11:20:00Z'
      },
      {
        id: 'comment3',
        userId: 'user2',
        content: 'Thank you! I use a Sony Alpha with a 50mm lens for most of these shots.',
        createdAt: '2023-03-15T13:45:00Z'
      }
    ],
    createdAt: '2023-03-15T10:00:00Z'
  },
  {
    id: 'post3',
    userId: 'user3',
    title: 'Introduction to Machine Learning',
    content: 'I\'ve been studying machine learning fundamentals. Here\'s what I\'ve learned about classification algorithms and how to implement them...',
    mediaUrls: [
      'https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Programming',
    tags: ['machinelearning', 'python', 'datascience'],
    likes: ['user1'],
    comments: [],
    createdAt: '2023-03-18T09:00:00Z'
  },
  {
    id: 'post4',
    userId: 'user4',
    title: 'Digital Illustration Techniques',
    content: 'I want to share some tips and tricks for digital illustration that I\'ve learned. These techniques have really improved my workflow...',
    mediaUrls: [
      'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/196645/pexels-photo-196645.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Design',
    tags: ['illustration', 'digitalart', 'drawing'],
    likes: ['user2', 'user3'],
    comments: [
      {
        id: 'comment4',
        userId: 'user1',
        content: 'Love your style! Do you have any recommendations for beginner digital artists?',
        createdAt: '2023-03-22T16:15:00Z'
      }
    ],
    createdAt: '2023-03-22T14:00:00Z'
  }
];

export const mockLearningPlans: LearningPlan[] = [
  {
    id: 'plan1',
    userId: 'user1',
    title: 'Mastering React from Fundamentals to Advanced',
    description: 'A comprehensive learning path to become proficient with React, including hooks, context, and performance optimization.',
    category: 'Programming',
    milestones: [
      {
        id: 'milestone1',
        title: 'React Fundamentals',
        description: 'Learn the basics of React, components, and props',
        isCompleted: true,
        targetDate: '2023-04-01T00:00:00Z'
      },
      {
        id: 'milestone2',
        title: 'State Management',
        description: 'Master useState, useReducer, and React Context',
        isCompleted: true,
        targetDate: '2023-04-15T00:00:00Z'
      },
      {
        id: 'milestone3',
        title: 'Advanced Hooks',
        description: 'Deep dive into useEffect, useCallback, and useMemo',
        isCompleted: false,
        targetDate: '2023-05-01T00:00:00Z'
      },
      {
        id: 'milestone4',
        title: 'Performance Optimization',
        description: 'Techniques for optimizing React application performance',
        isCompleted: false,
        targetDate: '2023-05-15T00:00:00Z'
      }
    ],
    duration: 45,
    currentProgress: 50,
    createdAt: '2023-03-15T10:00:00Z'
  },
  {
    id: 'plan2',
    userId: 'user2',
    title: 'Gourmet Cooking Skills',
    description: 'A step-by-step plan to master essential cooking techniques and signature dishes.',
    category: 'Cooking',
    milestones: [
      {
        id: 'milestone5',
        title: 'Knife Skills',
        description: 'Master different cutting techniques',
        isCompleted: true,
        targetDate: '2023-04-05T00:00:00Z'
      },
      {
        id: 'milestone6',
        title: 'Sauces & Stocks',
        description: 'Learn to make basic sauces and stocks from scratch',
        isCompleted: true,
        targetDate: '2023-04-20T00:00:00Z'
      },
      {
        id: 'milestone7',
        title: 'Meat Cookery',
        description: 'Different methods of cooking various meats',
        isCompleted: false,
        targetDate: '2023-05-10T00:00:00Z'
      }
    ],
    duration: 60,
    currentProgress: 65,
    createdAt: '2023-03-01T10:00:00Z'
  },
  {
    id: 'plan3',
    userId: 'user3',
    title: 'Data Science Fundamentals',
    description: 'Learning path to master the basics of data science and machine learning.',
    category: 'Programming',
    milestones: [
      {
        id: 'milestone8',
        title: 'Python for Data Science',
        description: 'Master Python libraries like NumPy and Pandas',
        isCompleted: true,
        targetDate: '2023-04-10T00:00:00Z'
      },
      {
        id: 'milestone9',
        title: 'Data Visualization',
        description: 'Learn to create insightful visualizations with Matplotlib and Seaborn',
        isCompleted: false,
        targetDate: '2023-04-25T00:00:00Z'
      },
      {
        id: 'milestone10',
        title: 'Machine Learning Basics',
        description: 'Understand classification, regression, and clustering algorithms',
        isCompleted: false,
        targetDate: '2023-05-20T00:00:00Z'
      }
    ],
    duration: 90,
    currentProgress: 30,
    createdAt: '2023-03-05T10:00:00Z'
  }
];

export const mockNotifications: Notification[] = [
  {
    id: 'notif1',
    userId: 'user1',
    triggeredBy: 'user2',
    type: 'like',
    entityId: 'post1',
    isRead: false,
    createdAt: '2023-03-10T15:00:00Z'
  },
  {
    id: 'notif2',
    userId: 'user1',
    triggeredBy: 'user2',
    type: 'comment',
    entityId: 'comment1',
    isRead: true,
    createdAt: '2023-03-10T15:30:00Z'
  },
  {
    id: 'notif3',
    userId: 'user2',
    triggeredBy: 'user1',
    type: 'follow',
    entityId: 'user2',
    isRead: false,
    createdAt: '2023-03-12T09:15:00Z'
  },
  {
    id: 'notif4',
    userId: 'user2',
    triggeredBy: 'user4',
    type: 'comment',
    entityId: 'comment2',
    isRead: false,
    createdAt: '2023-03-15T11:20:00Z'
  }
];