import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Image, X, Upload } from 'lucide-react';
import { useSkillShare } from '../context/SkillShareContext';

const CreatePostPage = () => {
  const { createPost } = useSkillShare();
  const navigate = useNavigate();
  
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('');
  const [tags, setTags] = useState('');
  const [mediaUrls, setMediaUrls] = useState<string[]>([]);
  const [mediaPreview, setMediaPreview] = useState<string[]>([]);
  
  // For demo purposes, using preset image URLs
  const demoImageUrls = [
    'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/6238297/pexels-photo-6238297.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/1779487/pexels-photo-1779487.jpeg?auto=compress&cs=tinysrgb&w=600'
  ];
  
  const categories = [
    'Programming', 
    'Design', 
    'Photography', 
    'Cooking', 
    'Languages', 
    'Music', 
    'Fitness',
    'Business'
  ];
  
  const addDemoImage = () => {
    // Limit to 3 images maximum
    if (mediaUrls.length >= 3) return;
    
    // Get a random image from the demo URLs
    const randomIndex = Math.floor(Math.random() * demoImageUrls.length);
    const newImage = demoImageUrls[randomIndex];
    
    setMediaUrls([...mediaUrls, newImage]);
    setMediaPreview([...mediaPreview, newImage]);
  };
  
  const removeMedia = (index: number) => {
    const updatedUrls = [...mediaUrls];
    const updatedPreviews = [...mediaPreview];
    
    updatedUrls.splice(index, 1);
    updatedPreviews.splice(index, 1);
    
    setMediaUrls(updatedUrls);
    setMediaPreview(updatedPreviews);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Parse tags
    const tagsList = tags.split(',').map(tag => tag.trim().toLowerCase()).filter(Boolean);
    
    createPost({
      title,
      content,
      mediaUrls,
      category,
      tags: tagsList
    });
    
    // Navigate to home page after posting
    navigate('/');
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="border-b border-gray-200 p-6">
          <h1 className="text-2xl font-bold text-gray-900">Create Post</h1>
          <p className="text-gray-600 mt-1">Share your learning journey and skills</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          <div className="space-y-6">
            {/* Title */}
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Title
              </label>
              <input
                id="title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="What is your post about?"
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            
            {/* Content */}
            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
                Content
              </label>
              <textarea
                id="content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Share your knowledge, experience, or ask a question..."
                required
                rows={6}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              ></textarea>
            </div>
            
            {/* Media */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Media (Max 3 photos)
              </label>
              
              <div className="mt-1 flex items-center space-x-4">
                <button
                  type="button"
                  onClick={addDemoImage}
                  disabled={mediaUrls.length >= 3}
                  className={`flex items-center justify-center h-24 w-24 border-2 border-dashed rounded-lg focus:outline-none ${
                    mediaUrls.length >= 3 
                      ? 'border-gray-300 cursor-not-allowed' 
                      : 'border-blue-500 hover:bg-blue-50 cursor-pointer'
                  }`}
                >
                  <Image size={24} className={mediaUrls.length >= 3 ? 'text-gray-400' : 'text-blue-500'} />
                </button>
                
                {mediaPreview.map((url, index) => (
                  <div key={index} className="relative h-24 w-24">
                    <img
                      src={url}
                      alt={`Preview ${index + 1}`}
                      className="h-24 w-24 object-cover rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => removeMedia(index)}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 focus:outline-none"
                    >
                      <X size={16} />
                    </button>
                  </div>
                ))}
              </div>
              
              <p className="text-xs text-gray-500 mt-2">
                {3 - mediaUrls.length} more photo{3 - mediaUrls.length !== 1 ? 's' : ''} can be added
              </p>
            </div>
            
            {/* Category and Tags */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  id="category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select a category</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label htmlFor="tags" className="block text-sm font-medium text-gray-700 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  id="tags"
                  type="text"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  placeholder="webdev, javascript, react"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 mt-8">
            <button
              type="button"
              onClick={() => navigate('/')}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition-colors"
            >
              Publish Post
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreatePostPage;