import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/Tabs';
import PostCard from '../components/posts/PostCard';
import LearningPlanCard from '../components/learning/LearningPlanCard';
import { useSkillShare } from '../context/SkillShareContext';

const HomePage = () => {
  const { posts, learningPlans, currentUser } = useSkillShare();
  const [activeTab, setActiveTab] = useState("feed");
  
  // Filter posts based on who the current user follows
  const followedUserIds = currentUser?.following || [];
  
  const feedPosts = posts.filter(post => 
    // Include posts from followed users and the current user's posts
    followedUserIds.includes(post.userId) || post.userId === currentUser?.id
  );
  
  const allPosts = [...posts].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  
  // Sort learning plans by creation date (newest first)
  const recentLearningPlans = [...learningPlans].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Welcome Back</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="feed">Your Feed</TabsTrigger>
          <TabsTrigger value="discover">Discover</TabsTrigger>
          <TabsTrigger value="learning">Learning Plans</TabsTrigger>
        </TabsList>
        
        <TabsContent value="feed">
          {feedPosts.length > 0 ? (
            <div className="space-y-4">
              {feedPosts.map(post => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 px-4 rounded-lg bg-white border border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Your feed is empty
              </h3>
              <p className="text-gray-600 mb-6">
                Follow other users to see their posts here, or explore the Discover tab to find new content.
              </p>
              <button 
                onClick={() => setActiveTab("discover")}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                Discover Content
              </button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="discover">
          <div className="space-y-4">
            {allPosts.map(post => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="learning">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {recentLearningPlans.map(plan => (
              <LearningPlanCard key={plan.id} plan={plan} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default HomePage;