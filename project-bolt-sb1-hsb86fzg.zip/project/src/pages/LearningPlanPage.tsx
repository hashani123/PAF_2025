import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, CheckCircle2, Circle, Share2 } from 'lucide-react';
import { useSkillShare } from '../context/SkillShareContext';
import { mockUsers } from '../data/mockData';

const LearningPlanPage = () => {
  const { planId } = useParams<{ planId: string }>();
  const { learningPlans, updateLearningProgress } = useSkillShare();
  
  const plan = learningPlans.find(p => p.id === planId);
  
  if (!plan) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Learning Plan Not Found</h2>
        <p className="text-gray-600">The learning plan you're looking for doesn't exist.</p>
        <Link 
          to="/"
          className="inline-block mt-6 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Back to Home
        </Link>
      </div>
    );
  }
  
  const user = mockUsers.find(u => u.id === plan.userId);
  
  const completedMilestones = plan.milestones.filter(m => m.isCompleted).length;
  const totalMilestones = plan.milestones.length;
  const progress = Math.round((completedMilestones / totalMilestones) * 100);
  
  const handleProgressUpdate = (newProgress: number) => {
    updateLearningProgress(plan.id, newProgress);
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <Link 
          to="/"
          className="inline-flex items-center text-gray-600 hover:text-blue-600 transition-colors"
        >
          <ArrowLeft size={20} className="mr-1" />
          <span>Back</span>
        </Link>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
        <div className="p-6">
          <div className="flex items-center mb-4">
            <img
              src={user?.avatar}
              alt={user?.name}
              className="w-10 h-10 rounded-full object-cover border border-gray-200"
            />
            <div className="ml-3">
              <Link 
                to={`/profile/${user?.id}`}
                className="font-medium text-gray-900 hover:text-blue-600"
              >
                {user?.name}
              </Link>
              <p className="text-sm text-gray-500">
                Created {formatDate(plan.createdAt)}
              </p>
            </div>
            <span className="ml-auto px-3 py-1 text-sm font-medium rounded-full bg-blue-100 text-blue-800">
              {plan.category}
            </span>
          </div>
          
          <h1 className="text-2xl font-bold text-gray-900 mb-2">{plan.title}</h1>
          <p className="text-gray-700 mb-6">{plan.description}</p>
          
          <div className="flex flex-col md:flex-row md:items-center md:justify-between bg-gray-50 p-4 rounded-lg mb-6">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="mr-6">
                <p className="text-sm text-gray-500">Duration</p>
                <p className="font-semibold text-gray-900">{plan.duration} days</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Milestones</p>
                <p className="font-semibold text-gray-900">{totalMilestones}</p>
              </div>
            </div>
            
            <div>
              <p className="text-sm text-gray-500 mb-1">Overall Progress</p>
              <div className="flex items-center">
                <div className="w-48 bg-gray-200 rounded-full h-2.5 mr-3">
                  <div 
                    className="bg-blue-600 h-2.5 rounded-full" 
                    style={{ width: `${plan.currentProgress}%` }}
                  ></div>
                </div>
                <span className="font-medium text-gray-900">{plan.currentProgress}%</span>
              </div>
            </div>
          </div>
          
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Milestones</h2>
            <div className="space-y-4">
              {plan.milestones.map((milestone, index) => (
                <div 
                  key={milestone.id}
                  className={`p-4 border rounded-lg ${
                    milestone.isCompleted ? 'border-green-200 bg-green-50' : 'border-gray-200'
                  }`}
                >
                  <div className="flex items-start">
                    <div className="mt-0.5">
                      {milestone.isCompleted ? (
                        <CheckCircle2 
                          size={20} 
                          className="text-green-500" 
                        />
                      ) : (
                        <Circle 
                          size={20} 
                          className="text-gray-400" 
                        />
                      )}
                    </div>
                    <div className="ml-3 flex-1">
                      <div className="flex items-start justify-between">
                        <h3 className={`font-medium ${
                          milestone.isCompleted ? 'text-green-800' : 'text-gray-900'
                        }`}>
                          {milestone.title}
                        </h3>
                        <div className="flex items-center text-sm text-gray-500">
                          <Calendar size={14} className="mr-1" />
                          <span>{formatDate(milestone.targetDate)}</span>
                        </div>
                      </div>
                      <p className={`text-sm mt-1 ${
                        milestone.isCompleted ? 'text-green-600' : 'text-gray-600'
                      }`}>
                        {milestone.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">Update Progress</h2>
              <button 
                className="flex items-center text-gray-600 hover:text-blue-600"
                aria-label="Share"
              >
                <Share2 size={18} className="mr-1" />
                <span>Share Plan</span>
              </button>
            </div>
            
            <div className="mt-4 flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex-1">
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  value={plan.currentProgress}
                  onChange={e => handleProgressUpdate(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>0%</span>
                  <span>50%</span>
                  <span>100%</span>
                </div>
              </div>
              
              <div className="text-center bg-blue-100 text-blue-800 py-1 px-3 rounded-full font-semibold">
                {plan.currentProgress}%
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LearningPlanPage;