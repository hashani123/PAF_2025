import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Heart, MessageSquare, Share2, Bookmark, MoreHorizontal } from 'lucide-react';
import { useSkillShare } from '../context/SkillShareContext';
import { mockUsers } from '../data/mockData';
import CommentSection from '../components/posts/CommentSection';
import { formatTimeAgo } from '../utils/dateUtils';

const PostDetailPage = () => {
  const { postId } = useParams<{ postId: string }>();
  const { posts, currentUser, likePost } = useSkillShare();
  
  const post = posts.find(p => p.id === postId);
  
  if (!post) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Post Not Found</h2>
        <p className="text-gray-600">The post you're looking for doesn't exist.</p>
        <Link 
          to="/"
          className="inline-block mt-6 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Back to Home
        </Link>
      </div>
    );
  }
  
  const user = mockUsers.find(u => u.id === post.userId);
  const isLiked = currentUser ? post.likes.includes(currentUser.id) : false;
  
  const handleLikeClick = () => {
    likePost(post.id);
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <Link 
          to="/"
          className="inline-flex items-center text-gray-600 hover:text-blue-600 transition-colors"
        >
          <ArrowLeft size={20} className="mr-1" />
          <span>Back</span>
        </Link>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
        {/* Post Header */}
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <Link to={`/profile/${user?.id}`} className="flex items-center">
              <img
                src={user?.avatar}
                alt={user?.name}
                className="w-12 h-12 rounded-full object-cover border border-gray-200"
              />
              <div className="ml-3">
                <p className="font-medium text-gray-900">{user?.name}</p>
                <p className="text-sm text-gray-500">{formatTimeAgo(post.createdAt)}</p>
              </div>
            </Link>
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 text-sm font-medium rounded-full bg-blue-100 text-blue-800">
                {post.category}
              </span>
              <button 
                className="p-2 rounded-full hover:bg-gray-100 text-gray-500"
                aria-label="More options"
              >
                <MoreHorizontal size={20} />
              </button>
            </div>
          </div>
          
          {/* Post Title */}
          <h1 className="text-2xl font-bold text-gray-900 mb-4">{post.title}</h1>
          
          {/* Post Content */}
          <div className="mb-6">
            <p className="text-gray-700 whitespace-pre-line">{post.content}</p>
          </div>
          
          {/* Tags */}
          {post.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-6">
              {post.tags.map((tag, index) => (
                <span 
                  key={index}
                  className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
          
          {/* Post Media */}
          {post.mediaUrls.length > 0 && (
            <div className="mb-6 space-y-4">
              {post.mediaUrls.map((url, index) => (
                <div key={index} className="overflow-hidden rounded-lg">
                  <img 
                    src={url} 
                    alt={`Post media ${index + 1}`}
                    className="w-full h-auto"
                  />
                </div>
              ))}
            </div>
          )}
          
          {/* Post Meta */}
          <div className="border-t border-b border-gray-100 py-3 mb-6">
            <div className="flex items-center text-sm text-gray-600">
              <span>{post.likes.length} likes</span>
              <span className="mx-2">•</span>
              <span>{post.comments.length} comments</span>
            </div>
          </div>
          
          {/* Post Actions */}
          <div className="flex items-center mb-6">
            <button 
              className={`flex items-center mr-6 ${
                isLiked ? 'text-red-500' : 'text-gray-600 hover:text-red-500'
              }`}
              onClick={handleLikeClick}
              aria-label={isLiked ? 'Unlike' : 'Like'}
            >
              <Heart 
                size={20} 
                className={`mr-1.5 ${isLiked ? 'fill-current' : ''}`} 
              />
              <span>Like</span>
            </button>
            
            <button 
              className="flex items-center mr-6 text-gray-600 hover:text-blue-500"
              aria-label="Comment"
            >
              <MessageSquare size={20} className="mr-1.5" />
              <span>Comment</span>
            </button>
            
            <button 
              className="flex items-center mr-6 text-gray-600 hover:text-green-500"
              aria-label="Share"
            >
              <Share2 size={20} className="mr-1.5" />
              <span>Share</span>
            </button>
            
            <button 
              className="flex items-center text-gray-600 hover:text-purple-500 ml-auto"
              aria-label="Save"
            >
              <Bookmark size={20} className="mr-1.5" />
              <span>Save</span>
            </button>
          </div>
          
          {/* Comments Section */}
          <div className="border-t border-gray-100 pt-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Comments ({post.comments.length})
            </h2>
            <CommentSection postId={post.id} comments={post.comments} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostDetailPage;