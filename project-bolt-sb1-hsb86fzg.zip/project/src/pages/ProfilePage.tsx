import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/Tabs';
import ProfileHeader from '../components/profile/ProfileHeader';
import PostCard from '../components/posts/PostCard';
import LearningPlanCard from '../components/learning/LearningPlanCard';
import { useSkillShare } from '../context/SkillShareContext';
import { mockUsers } from '../data/mockData';

const ProfilePage = () => {
  const { userId } = useParams<{ userId: string }>();
  const { posts, learningPlans } = useSkillShare();
  const [activeTab, setActiveTab] = useState('posts');
  
  const user = mockUsers.find(u => u.id === userId);
  
  // Filter posts by this user
  const userPosts = posts.filter(post => post.userId === userId);
  
  // Filter learning plans by this user
  const userPlans = learningPlans.filter(plan => plan.userId === userId);
  
  if (!user) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">User Not Found</h2>
        <p className="text-gray-600">The user profile you're looking for doesn't exist.</p>
      </div>
    );
  }

  return (
    <div>
      <ProfileHeader user={user} />
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="posts">Posts</TabsTrigger>
          <TabsTrigger value="plans">Learning Plans</TabsTrigger>
          <TabsTrigger value="progress">Progress</TabsTrigger>
        </TabsList>
        
        <TabsContent value="posts">
          {userPosts.length > 0 ? (
            <div className="space-y-4">
              {userPosts.map(post => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 px-4 rounded-lg bg-white border border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No posts yet
              </h3>
              <p className="text-gray-600">
                {userId === userId ? 
                  "You haven't shared any posts yet. Start sharing your learning journey!" :
                  "This user hasn't shared any posts yet."}
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="plans">
          {userPlans.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {userPlans.map(plan => (
                <LearningPlanCard key={plan.id} plan={plan} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 px-4 rounded-lg bg-white border border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No learning plans yet
              </h3>
              <p className="text-gray-600">
                {userId === userId ? 
                  "You haven't created any learning plans yet. Create a plan to track your progress!" :
                  "This user hasn't created any learning plans yet."}
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="progress">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Learning Progress</h3>
            <p className="text-gray-600">
              Progress tracking features coming soon!
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProfilePage;