export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  bio: string;
  skills: string[];
  following: string[];
  followers: string[];
  joinedAt: string;
}

export interface Comment {
  id: string;
  userId: string;
  content: string;
  createdAt: string;
}

export interface Post {
  id: string;
  userId: string;
  title: string;
  content: string;
  mediaUrls: string[];
  category: string;
  tags: string[];
  likes: string[];
  comments: Comment[];
  createdAt: string;
}

export interface LearningPlan {
  id: string;
  userId: string;
  title: string;
  description: string;
  category: string;
  milestones: Milestone[];
  duration: number; // in days
  currentProgress: number; // percentage
  createdAt: string;
}

export interface Milestone {
  id: string;
  title: string;
  description: string;
  isCompleted: boolean;
  targetDate: string;
}

export interface Notification {
  id: string;
  userId: string;
  triggeredBy: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  entityId: string; // postId, commentId, etc.
  isRead: boolean;
  createdAt: string;
}